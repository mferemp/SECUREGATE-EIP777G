# SecureGate / EIP-777G — Full Battery Handoff

_Generated 2026-07-16T04:04:47Z · all proofs run under Node 24 (v24.18.0) + Foundry (forge 1.7.1)._

This document embeds every raw proof output verbatim below (sections 2, 4, 5, 6).
The identical logs also live as separate files under `handoff/proofs/`.

## 1. Repo / ZIP / branch deliverable

| Field | Value |
|-------|-------|
| Branch | `securegate/eip-777g-final-build` |
| Commit | `c9437df1f33a826866d922300203e98c16fa5409` |
| ZIP filename | `securegate-full-battery-handoff-<COMMIT7>.zip` (see section 7) |
| ZIP sha256 | see section 7 (printed at assembly) |
| Proof ZIP == commit | `git archive HEAD` of the repo subtree reproduces identical bytes |
| Tracked files in HEAD | 198 |
| Node | v24.18.0 (asserted major===24, log 02) |

## 2. Section-by-section labeled code + proof

### SECTION 01 — UI Baseline Integration

**Files changed / owned:**
- `frontend/src/App.tsx`
- `frontend/src/index.css`
- `frontend/src/lib/uiLabels.ts`
- `scripts/verify-ui-baseline.cjs`

**Drift rules:** Preserve UI_FRONTEND_SPECS shell; no operator/revoke/QR/Flashbots vocab in UI.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-ui-baseline.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-ui-baseline.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS PROGRESS_LABELS is exactly the 5 canonical labels in order
PASS neutral K3 copy present (mechanics hidden)
PASS no forbidden mechanics vocabulary appears in exported UI strings
PASS safeLabel() redacts forbidden mechanics terms at runtime
PASS App.tsx imports PROGRESS_LABELS + HUMAN_ROUTE_MSG from uiLabels
PASS App.tsx does NOT hardcode a divergent progress-label array

verify-ui-baseline: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 02 — Canonical ABI / Artifact

**Files changed / owned:**
- `contracts/SecureGate.sol`
- `test/SecureGate.t.sol`
- `foundry.toml`
- `script/DeploySecureGate.s.sol`
- `scripts/extract-bytecode.js`
- `scripts/verify-abi-canonical.cjs`
- `out/SecureGate.sol/SecureGate.json`

**Drift rules:** New ABI only (queueERC20/authorizeIntent/executeIntent...); forbid queueIntent/forwardERC20/computeEIP712Digest/domainSeparator.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-abi-canonical.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-abi-canonical.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
PASS canonical artifact was produced by a Foundry build (bytecode present)
PASS required ABI present: DOMAIN_SEPARATOR()
PASS required ABI present: GATE_CHAIN_ID()
PASS required ABI present: K1()
PASS required ABI present: K2()
PASS required ABI present: K3()
PASS required ABI present: authorizeIntent(bytes32,bytes)
PASS required ABI present: computeAuthorizationDigest(bytes32)
PASS required ABI present: computeIntentHash(uint8,address,uint256,uint256,bytes32,uint256)
PASS required ABI present: executeIntent(bytes32)
PASS required ABI present: intents(bytes32)
PASS required ABI present: queueERC1155(address,uint256,uint256,bytes32,uint256)
PASS required ABI present: queueERC20(address,uint256,bytes32,uint256)
PASS required ABI present: queueERC721(address,uint256,bytes32,uint256)
PASS required ABI present: recordAttemptedDestination(address)
PASS required ABI present: suspectDestination(address)
PASS required ABI present: usedNonces(bytes32)
PASS forbidden old ABI absent: queueIntent
PASS forbidden old ABI absent: forwardERC20
PASS forbidden old ABI absent: computeEIP712Digest
PASS forbidden old ABI absent: domainSeparator
     abiEntries=37 bytecodeBytes=7030 bytecodeSha256=09802e801b83f894d804bf818c51f099c407cbe41d769fbecd4f87f62a020f55
PASS ABI entry count + bytecode size reported

verify-abi-canonical: 22 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 03 — Auth-Gate Session + Sweep

**Files changed / owned:**
- `frontend/src/lib/authGateSession.ts`
- `frontend/src/lib/authGateSweep.ts`
- `frontend/src/lib/authGateAttempts.ts`
- `scripts/verify-authgate-session.cjs`
- `scripts/verify-authgate-sweep.cjs`
- `scripts/verify-authgate-attempt-limits.cjs`

**Drift rules:** K1 bound to session; sweep never moves assets; 3 device fails darken SCAN/LINK; passkey lane stays open.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-authgate-session.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-session.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS S04: fresh session is unbound with no K1 (fresh-per-use)
PASS S04: a gate must be blocked until a valid K1 is entered
PASS S04: binding K1 makes it session-bound and auto-fills downstream
PASS S04: a different K1 cannot silently overwrite a bound session
PASS S04: resetSession restores a clean unbound session (fresh-per-use)
PASS S05: SCAN is a same-device sweep that never verifies/unlocks
PASS S05: LINK DEVICE is a usb-linked-device sweep that never verifies/unlocks
PASS S06: 3 failed device attempts darken SCAN+LINK for that K1
PASS S06: passkey + human routes stay OPEN after device lockout
PASS S06: a success clears failures; a new K1 resets the counter (per-K1)

verify-authgate-session: 10 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 04 — Device Breadcrumb / Download Trace

**Files changed / owned:**
- `frontend/src/lib/deviceBreadcrumb.ts`
- `backend/routes/trace.js`
- `backend/lib/trace-store.js`
- `backend/scripts/verify-device-breadcrumb.cjs`

**Drift rules:** Breadcrumb for recovery/Auth-Gate/download abuse only; must NOT limit 2FA.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `cd backend && ../scripts/with-node24.sh node scripts/verify-device-breadcrumb.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-device-breadcrumb.cjs
### CWD: /workspaces/backend
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS S04: canonical trace events include all required names
PASS S04: every trace event has an explicit TTL window
PASS S04: breadcrumbs NEVER limit 2FA
PASS S04: recordEvent uses the event TTL and rejects unknown events
PASS S07: trace key is opaque (no raw subject material)
PASS S07: repeated breadcrumbs increment a coarse count
PASS S07: crossing the repeat threshold sets flagged=true (signal only)
PASS S07: distinct subjects do not collide
PASS S07: /api/trace route exists and uses anti-abuse + trace-store

verify-device-breadcrumb: 9 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 05 — Passkey Lane

**Files changed / owned:**
- `frontend/src/lib/passkeyAccess.ts`
- `backend/lib/passkey-store.js`
- `backend/routes/passkeys.js`
- `scripts/verify-authgate-passkey.cjs`

**Drift rules:** Passkey K1-bound not per-chain; backend stores only salted 64-hex digest; verified passkey is human-route signal only.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-authgate-passkey.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-passkey.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS PASSKEY input + ENTER button render below LINK DEVICE
PASS passkey lane stays enabled while SCAN/LINK are darkened (devicesLocked)
PASS register stores ONLY a salted digest (raw passkey never persisted)
PASS correct passkey verifies; mismatch fails closed
PASS passkey is K1-bound, not per-chain (digest keyed on K1 only)
PASS client wrapper treats a verified passkey as human-route signal ONLY

verify-authgate-passkey: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 06 — Admin Black-Circle Passkey

**Files changed / owned:**
- `frontend/src/lib/adminPasskey.ts`
- `backend/routes/admin-passkey.js`
- `scripts/verify-admin-passkey.cjs`

**Drift rules:** Admin key + K1 -> K1-bound passkey; no operator surface.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-admin-passkey.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-admin-passkey.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS route mints a K1-BOUND passkey (not per-chain)
PASS route honestly reports disabled when ADMIN_KEY is unset (no fake success)
PASS admin key constant-time compared and never stored/echoed
PASS minted passkey registered to the K1-bound passkey store
PASS client wrapper posts once and reports disabled honestly
PASS compact black-circle panel only — NO admin tabs / relay / operator console / revoke / veil
PASS App wires the admin mint via generateAdminPasskeyRemote

verify-admin-passkey: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 07 — 2FA Proactive No-Limits

**Files changed / owned:**
- `frontend/src/lib/twoFactorProactive.ts`
- `scripts/verify-2fa-no-limits.cjs`

**Drift rules:** 2FA separate & proactive; no recovery limits; not gated by Auth-Gate attempts/downloads/passkey fails; no compromised K1 key.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-2fa-no-limits.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-2fa-no-limits.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS S10: 2FA reports NO recovery limit
PASS S10: 2FA NEVER requires a private key
PASS S10: 2FA NEVER gates/unlocks execution
PASS S10: 2FA is proactive + not active yet (honest, no fake success)
PASS S10: App.tsx renders honest 2FA status via twoFactorStatus()

verify-2fa-no-limits: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 08 — Recovery Flow + Funding

**Files changed / owned:**
- `frontend/src/lib/recoveryCleanupSweep.ts`
- `frontend/src/lib/securegateTxBuilder.ts`
- `frontend/src/lib/api.ts`
- `backend/routes/funding.js`
- `scripts/verify-recovery-flow-ui.cjs`
- `scripts/verify-funding-gas.cjs`

**Drift rules:** Funding/gas via backend route only; no frontend RPC URLs; public progress labels exact.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-funding-gas.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-funding-gas.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS funding route exists at GET /api/funding/:chain
PASS funding estimate uses backend RPC (chains.rpcUrlFor)
PASS funding response returns NO rpc endpoint URL
PASS funding computes a real gas estimate (eth_gasPrice * gas)
PASS funding estimate is not a fabricated constant string
PASS client reaches gas/funding data through backend routes only (no direct provider URL)
PASS client funding path carries no private-key material

verify-funding-gas: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 09 — Recovery Cleanup Sweep

**Files changed / owned:**
- `frontend/src/lib/recoveryCleanupSweep.ts`
- `scripts/verify-recovery-cleanup-sweep.cjs`

**Drift rules:** Cleanup sweep must not leak into 2FA.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-recovery-cleanup-sweep.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-recovery-cleanup-sweep.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS freshScratch() starts with both secrets blank
PASS scrub() wipes both secrets in place
PASS FORBIDDEN_BACKEND_KEYS covers every session secret name
PASS isBackendSafe rejects any key-shaped field
PASS backendDeployBody yields signedTx ONLY

verify-recovery-cleanup-sweep: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 10 — K3 Enforcement / Blacklist / Execution Sweep

**Files changed / owned:**
- `frontend/src/lib/k3Enforcement.ts`
- `frontend/src/lib/k3ExecutionSweep.ts`
- `backend/lib/address-guard.js`
- `backend/routes/deploy.js`
- `scripts/verify-blacklist-k3.cjs`
- `scripts/verify-k3-execution-sweep.cjs`

**Drift rules:** Assets route ONLY to K3; non-K3 captured/blacklisted; deploy route rejects override-destination keys.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-blacklist-k3.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-blacklist-k3.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS contract executes ONLY to K3 (transfer targets K3, never a param)
PASS contract captures a non-K3 destination as suspect (blacklist), never routes it
PASS K3 is immutable in the contract
PASS backend guard keeps forcedDestination == K3 even when override requested
PASS backend guard rejects override-smuggling body keys
PASS frontend mirror always returns K3 with neutral copy

verify-blacklist-k3: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 11 — K2 Authorization + Intent Hash

**Files changed / owned:**
- `frontend/src/lib/securegateIntentHash.ts`
- `frontend/src/lib/securegateK2Authorization.ts`
- `frontend/src/lib/securegateWalletProvider.ts`
- `scripts/verify-k2-intent-builders.cjs`
- `scripts/verify-wallet-k2-flow.cjs`

**Drift rules:** K2 authorizes via EIP-712 signature only; never a K2 key; rejects all-zero signature.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-k2-intent-builders.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-k2-intent-builders.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS  anvil chainId matches contract GATE_CHAIN_ID
PASS  ERC20: client intentHash == on-chain computeIntentHash
PASS  ERC20: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC20: client verify recovers K2
PASS  ERC20: contract accepts authorizeIntent with the K2 sig
PASS  ERC20: wrong expected-K2 => valid=false
PASS  ERC20: wrong chainId => not K2
PASS  ERC20: wrong verifyingContract => not K2
PASS  ERC20: wrong intentHash => not K2
PASS  ERC721: client intentHash == on-chain computeIntentHash
PASS  ERC721: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC721: client verify recovers K2
PASS  ERC721: contract accepts authorizeIntent with the K2 sig
PASS  ERC721: wrong expected-K2 => valid=false
PASS  ERC721: wrong chainId => not K2
PASS  ERC721: wrong verifyingContract => not K2
PASS  ERC721: wrong intentHash => not K2
PASS  ERC1155: client intentHash == on-chain computeIntentHash
PASS  ERC1155: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC1155: client verify recovers K2
PASS  ERC1155: contract accepts authorizeIntent with the K2 sig
PASS  ERC1155: wrong expected-K2 => valid=false
PASS  ERC1155: wrong chainId => not K2
PASS  ERC1155: wrong verifyingContract => not K2
PASS  ERC1155: wrong intentHash => not K2
PASS  rejects empty signature
PASS  rejects all-zero 65-byte signature
PASS  rejects malformed-length signature
PASS  computeClientIntentHash rejects zero token
PASS  computeClientIntentHash rejects zero verifyingContract
PASS  ACTION_TYPEHASH matches contract type string
PASS  AUTHORIZE_TYPEHASH matches contract type string

verify-k2-intent-builders: 32/32 passed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 12 — Frontend <-> Backend Wiring

**Files changed / owned:**
- `frontend/src/lib/api.ts`
- `backend/routes/artifact.js`
- `backend/routes/funding.js`
- `backend/routes/deploy.js`
- `backend/routes/runtime.js`
- `backend/routes/trace.js`
- `backend/routes/thank-you.js`
- `scripts/verify-front-back-wiring.cjs`

**Drift rules:** Backend receives signedTx only; RPC URLs backend-env only; no private keys posted.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:20Z
----------------------------------------------------------------
PASS App imports from ./lib/uiLabels and uses UI_PROGRESS_LABELS
PASS App imports from ./lib/deviceBreadcrumb and uses pingDevice
PASS App imports from ./lib/passkeyAccess and uses verifyPasskey
PASS App imports from ./lib/adminPasskey and uses generateAdminPasskeyRemote
PASS App imports from ./lib/twoFactorProactive and uses twoFactorStatus
PASS App imports from ./lib/k3Enforcement and uses enforceK3
PASS App imports from ./lib/recoveryCleanupSweep and uses isBackendSafe
PASS App imports from ./lib/k3ExecutionSweep and uses sweepTargetsOnlyK3
PASS App imports from ./lib/thankYouEnvelope and uses thankYouIsNotK3
PASS App broadcast() fails closed on key-bearing payloads (isBackendSafe guard)
PASS App execute path enforces K3 before broadcasting
PASS backend route exists: /api/trace
PASS backend route exists: /api/passkeys
PASS backend route exists: /api/admin-passkey
PASS backend route exists: /api/funding
PASS backend route exists: /api/deploy
PASS backend route exists: /api/anti-abuse
PASS backend route exists: /api/thank-you
PASS backend route exists: /api/chains
PASS backend route exists: /api/rpc

verify-front-back-wiring: 20 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 13 — Thank-You Envelope

**Files changed / owned:**
- `frontend/src/lib/thankYouEnvelope.ts`
- `backend/routes/thank-you.js`
- `scripts/verify-thank-you-envelope.cjs`

**Drift rules:** Thank-you address is separate from K3 and cannot affect routing.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-thank-you-envelope.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-thank-you-envelope.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:20Z
----------------------------------------------------------------
PASS thankYouIsNotK3 blocks a thank-you address equal to K3
PASS thank-you config exposes copyAddress as copy-only (no destination role)
PASS App uses thankYouIsNotK3 guard before copying the tip address
PASS thank-you address is NOT wired into any deploy/proof/execution body
PASS backend thank-you route is honest-capability (disabled unless configured)

verify-thank-you-envelope: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 14 — Obfuscation / Anti-Clone

**Files changed / owned:**
- `scripts/verify-contract-obfuscation-layers.cjs`
- `scripts/verify-obfuscation-ci.cjs`
- `docs/obfuscation-ci.md`

**Drift rules:** No obfuscated build configured -> must SKIP honestly; obfuscation must never change ABI/K3 routing.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-contract-obfuscation-layers.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-contract-obfuscation-layers.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS canonical Foundry artifact exists and carries real bytecode
PASS no fabricated / placeholder obfuscated artifact is committed
PASS source honestly documents the missing layer (no false completeness claim)
SKIPPED: no obfuscated build configured
NOTE: Contract/dashboard obfuscation is NOT complete.

verify-contract-obfuscation-layers: 3 passed, 0 failed (obfuscation build SKIPPED)
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 15 — Anti-Abuse Without Extra Guardrails

**Files changed / owned:**
- `backend/lib/anti-abuse-kv.js`
- `scripts/verify-anti-abuse-downloads.cjs`

**Drift rules:** All 900s are abuse TTL/window, NOT a K1->K2 cooldown; MIN_DELAY absent.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-anti-abuse-downloads.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-anti-abuse-downloads.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS anti-abuse limits include dashboard_download and dashboard_ping
PASS repeated downloads eventually flag (breadcrumb count crosses threshold)
PASS anti-abuse record() eventually disallows beyond the max window
PASS trace key is opaque — a raw subject is NOT recoverable from it
PASS canonical event vocabulary excludes 2FA (breadcrumbs never limit 2FA)
PASS recordEvent rejects an unknown event (fail closed)
PASS trace route stores NO raw subject (reduces to bucketKey before recording)

verify-anti-abuse-downloads: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### SECTION 16 — Placeholder Honesty

**Files changed / owned:**
- `frontend/src/lib/placeholderGates.ts`
- `scripts/verify-placeholder-gates.cjs`

**Drift rules:** Placeholders declared honestly; no fake txHash/pending/verified.

**Full code:** shipped verbatim in the ZIP at the exact paths above (and inlined in
`SECUREGATE-BUILD-CODE-HANDOFF.md`). Not re-pasted here to keep proofs readable.

**Proof command:** `scripts/with-node24.sh node scripts/verify-placeholder-gates.cjs`

**Exact output:**
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-placeholder-gates.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS gate "scan" returns verified:false and cannot unlock
PASS gate "link" returns verified:false and cannot unlock
PASS gate "passkey" returns verified:false and cannot unlock
PASS gate "admin" returns verified:false and cannot unlock
PASS gate "twofa" returns verified:false and cannot unlock
PASS no gate message claims success/verified/unlocked/complete
PASS canExecuteIntent(false, []) === false (no K2 sig)
PASS canExecuteIntent(true, []) === true (K2 sig verified)
PASS any pile of honest placeholders cannot unlock when K2 unverified
PASS honest placeholders do not block a genuine K2-verified execution
PASS forged verified:true placeholder is rejected by canExecuteIntent
PASS forged unlocksExecution:true placeholder is rejected
PASS isPlaceholderResult guard rejects forged / verified objects
PASS PENDING_PLACEHOLDER_LAYERS lists all five hard placeholder layers
PASS PLACEHOLDER_GATE_MESSAGES defines all five gate kinds
PASS placeholderGates.ts contains no "verified: true" (code, comments stripped)
PASS placeholderGates.ts contains no "unlocksExecution: true" (code)
PASS placeholderGates.ts performs no network/credential/key operations
PASS App.tsx imports the placeholder honesty gates
PASS App.tsx has no private MSG placeholder map (single source of truth)
PASS App.tsx gates executeIntent through canExecuteIntent(authVerified, …)

placeholder-gates: 21 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

## 3. No-added-guardrails ledger

| Guardrail check | Required | PASS/FAIL | Evidence path |
|---|---|---|---|
| UI spec used as frontend baseline | yes | PASS | frontend/src/App.tsx + scripts/verify-ui-baseline.cjs (v01) |
| stale operator/revoke/QR copied | no | PASS | scripts/verify-csp.cjs / verify-mobile-ci.cjs / verify-admin-passkey.cjs assertions |
| 2FA blocked by Auth-Gate attempts | no | PASS | scripts/verify-2fa-no-limits.cjs (v09) |
| 2FA blocked by dashboard downloads | no | PASS | scripts/verify-2fa-no-limits.cjs (v09) |
| 2FA requires compromised K1 private key | no | PASS | frontend/src/lib/twoFactorProactive.ts + v09 |
| 900-second K1->K2 cooldown added | no | PASS | drift scan: no MIN_DELAY; 900s only in anti-abuse-kv/trace-store TTL |
| 900-second values only abuse TTL/window if present | yes | PASS | backend/lib/anti-abuse-kv.js windowSec:900 / trace-store.js ttlSec:900 |
| passkey route remains after SCAN/LINK disabled | yes | PASS | scripts/verify-authgate-passkey.cjs (v07) |
| normal multi-chain recovery for same K1 allowed | yes | PASS | backend/lib/anti-abuse-kv.js (per-abuse counters, not per-chain block) |
| repeated dashboard-download throttling only recovery/download abuse | yes | PASS | scripts/verify-anti-abuse-downloads.cjs (v21) |
| K2 private key requested | no | PASS | scripts/verify-k2-intent-builders.cjs (v15) / verify-wallet-k2-flow.cjs (v16) |
| K3 private key requested | no | PASS | frontend/src/lib/k3Enforcement.ts + verify-blacklist-k3.cjs (v13) |
| K1/deployer private keys sent to backend | no | PASS | scripts/verify-front-back-wiring.cjs (v17); backend routes read no *_PRIVATE_KEY |
| backend receives signedTx only | yes | PASS | backend/routes/deploy.js + verify-front-back-wiring.cjs (v17) |
| public frontend RPC URL | no | PASS | scripts/verify-funding-gas.cjs (v11); api.ts proxies via backend |
| backend exposes RPC URL to frontend | no | PASS | backend/config/chains.js listPublic() omits rpcEnv/URL |
| operator/revoke/QR flow | no | PASS | verify-ui-baseline.cjs (v01) / verify-csp.cjs |
| old ABI active | no | PASS | scripts/verify-abi-canonical.cjs (07) / verify-no-drift.cjs (v02) |
| SecureGate-Canonical (2)/(3).sol used | no | PASS | only contracts/SecureGate.sol tracked; git ls-tree |
| thank-you address affects K3 | no | PASS | scripts/verify-thank-you-envelope.cjs (v18) |
| fake txHash/pending/verified | no | PASS | scripts/verify-placeholder-gates.cjs (v22) |
| Auth-Gate sweep moves assets | no | PASS | scripts/verify-authgate-sweep.cjs (v04) |
| recovery cleanup sweep leaks into 2FA | no | PASS | scripts/verify-recovery-cleanup-sweep.cjs (v12) |
| K3 execution sweep can route non-K3 | no | PASS | scripts/verify-k3-execution-sweep.cjs (v14) |
| obfuscation changes ABI/K3 routing | no | PASS (obfuscation SKIPPED) | scripts/verify-contract-obfuscation-layers.cjs (v19) |
| active source depends on uploads/outputs/restored-original | no | PASS | scripts/verify-zip-contents.py active-root allowlist |
| production-ready claim | no | PASS | this document ends 'No production-ready claim.' |

## 4. Full exact Node 24 / Foundry / frontend / backend outputs

### Node -v
```text
### COMMAND: /workspaces/scripts/with-node24.sh node -v
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
v24.18.0
----------------------------------------------------------------
### EXIT: 0
```

### Node 24 assert
```text
### COMMAND: /workspaces/scripts/with-node24.sh node -e const m=Number(process.versions.node.split(".")[0]);if(m!==24){console.error("Wrong Node: "+process.version);process.exit(1)}console.log("Node 24 verified: "+process.version)
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
Node 24 verified: v24.18.0
----------------------------------------------------------------
### EXIT: 0
```

### forge --version
```text
### COMMAND: /workspaces/scripts/with-node24.sh forge --version
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
forge Version: 1.7.1
Commit SHA: 4072e48705af9d93e3c0f6e29e93b5e9a40caed8
Build Timestamp: 2026-05-08T07:50:55.527285345Z (1778226655)
Build Profile: dist
----------------------------------------------------------------
### EXIT: 0
```

### forge build --via-ir
```text
### COMMAND: /workspaces/scripts/with-node24.sh forge build --via-ir
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
No files changed, compilation skipped
warning[block-timestamp]: usage of `block.timestamp` in a comparison may be manipulated by validators
    ╭▸ contracts/SecureGate.sol:150:13
    │
150 │         if (deadline <= block.timestamp) revert InvalidDeadline();
    │             ━━━━━━━━━━━━━━━━━━━━━━━━━━━
    │
    ╰ help: https://book.getfoundry.sh/reference/forge/forge-lint#block-timestamp

warning[block-timestamp]: usage of `block.timestamp` in a comparison may be manipulated by validators
    ╭▸ contracts/SecureGate.sol:176:13
    │
176 │         if (block.timestamp > intent.deadline) revert InvalidDeadline();
    │             ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    │
    ╰ help: https://book.getfoundry.sh/reference/forge/forge-lint#block-timestamp

warning[block-timestamp]: usage of `block.timestamp` in a comparison may be manipulated by validators
    ╭▸ contracts/SecureGate.sol:191:13
    │
191 │         if (block.timestamp > intent.deadline) revert InvalidDeadline();
    │             ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
    │
    ╰ help: https://book.getfoundry.sh/reference/forge/forge-lint#block-timestamp

----------------------------------------------------------------
### EXIT: 0
```

### forge test -vvv
```text
### COMMAND: /workspaces/scripts/with-node24.sh forge test -vvv
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
No files changed, compilation skipped

Ran 4 tests for test/SecureGate.t.sol:SecureGateTest
[PASS] test_constructor_sets_keys() (gas: 14005)
[PASS] test_k2_authorizes_and_k1_executes_to_k3() (gas: 202708)
[PASS] test_non_k3_destination_is_captured_not_routed() (gas: 35186)
[PASS] test_only_k1_can_queue() (gas: 154031)
Suite result: ok. 4 passed; 0 failed; 0 skipped; finished in 1.55ms (786.22µs CPU time)

Ran 1 test suite in 7.42ms (1.55ms CPU time): 4 tests passed, 0 failed, 0 skipped (4 total tests)
----------------------------------------------------------------
### EXIT: 0
```

### extract-bytecode
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/extract-bytecode.js
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
[extract-bytecode] wrote backend/.env.securegate
  SECUREGATE_BYTECODE_HEX      (7030 bytes)
  SECUREGATE_ABI_JSON          (37 ABI entries)
  SECUREGATE_ARTIFACT_SHA256   e957af0b477d8f49aa283c725ca45179fbf8e159c8522d10cdaf3aaa543e2404
  SECUREGATE_ARTIFACT_VERSION  securegate@e957af0b477d
----------------------------------------------------------------
### EXIT: 0
```

### verify-abi-canonical
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-abi-canonical.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------
PASS canonical artifact was produced by a Foundry build (bytecode present)
PASS required ABI present: DOMAIN_SEPARATOR()
PASS required ABI present: GATE_CHAIN_ID()
PASS required ABI present: K1()
PASS required ABI present: K2()
PASS required ABI present: K3()
PASS required ABI present: authorizeIntent(bytes32,bytes)
PASS required ABI present: computeAuthorizationDigest(bytes32)
PASS required ABI present: computeIntentHash(uint8,address,uint256,uint256,bytes32,uint256)
PASS required ABI present: executeIntent(bytes32)
PASS required ABI present: intents(bytes32)
PASS required ABI present: queueERC1155(address,uint256,uint256,bytes32,uint256)
PASS required ABI present: queueERC20(address,uint256,bytes32,uint256)
PASS required ABI present: queueERC721(address,uint256,bytes32,uint256)
PASS required ABI present: recordAttemptedDestination(address)
PASS required ABI present: suspectDestination(address)
PASS required ABI present: usedNonces(bytes32)
PASS forbidden old ABI absent: queueIntent
PASS forbidden old ABI absent: forwardERC20
PASS forbidden old ABI absent: computeEIP712Digest
PASS forbidden old ABI absent: domainSeparator
     abiEntries=37 bytecodeBytes=7030 bytecodeSha256=09802e801b83f894d804bf818c51f099c407cbe41d769fbecd4f87f62a020f55
PASS ABI entry count + bytecode size reported

verify-abi-canonical: 22 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### frontend type-check
```text
### COMMAND: /workspaces/scripts/with-node24.sh npm run type-check
### CWD: /workspaces/frontend
### DATE: 2026-07-16T04:04:10Z
----------------------------------------------------------------

> frontend@0.0.0 type-check
> tsc --noEmit --incremental

----------------------------------------------------------------
### EXIT: 0
```

### frontend build
```text
### COMMAND: /workspaces/scripts/with-node24.sh npm run build
### CWD: /workspaces/frontend
### DATE: 2026-07-16T04:04:12Z
----------------------------------------------------------------

> frontend@0.0.0 build
> node scripts/check-env.cjs npm run build:client && npm run build:server


> frontend@0.0.0 build:client
> vite build --outDir dist/client

vite v6.4.2 building for production...
transforming...
✓ 252 modules transformed.
rendering chunks...
computing gzip size...
dist/client/assets/lato-latin-ext-700-normal-C6gwlRgY.woff2               5.55 kB
dist/client/assets/lato-latin-ext-400-normal-CK4GAP86.woff2               5.61 kB
dist/client/assets/lato-latin-ext-900-normal-BhetttCG.woff2               5.64 kB
dist/client/assets/roboto-mono-vietnamese-wght-normal-DlC-zuDL.woff2     10.31 kB
dist/client/index.html                                                   11.03 kB │ gzip:   4.76 kB
dist/client/assets/roboto-mono-greek-wght-normal-BJJTbwTT.woff2          14.04 kB
dist/client/assets/lato-latin-900-normal-CZBfLiEO.woff                   17.19 kB
dist/client/assets/lato-latin-400-normal-B11PyLys.woff                   17.45 kB
dist/client/assets/lato-latin-700-normal-DAdL7O4w.woff                   17.62 kB
dist/client/assets/roboto-mono-cyrillic-wght-normal-HUlVHixE.woff2       18.59 kB
dist/client/assets/lato-latin-900-normal-C3uaq3BA.woff2                  22.50 kB
dist/client/assets/roboto-mono-latin-ext-wght-normal-QAYlOegK.woff2      22.92 kB
dist/client/assets/lato-latin-700-normal-BUGMgin4.woff2                  23.04 kB
dist/client/assets/lato-latin-400-normal-BEhtfm5r.woff2                  23.58 kB
dist/client/assets/roboto-mono-latin-wght-normal-CZtBPCCa.woff2          32.80 kB
dist/client/assets/roboto-mono-cyrillic-ext-wght-normal-BUDPrIko.woff2   35.91 kB
dist/client/assets/index-DSSSBYCM.css                                    88.14 kB │ gzip:  24.98 kB
dist/client/assets/index-Br42UDbl.js                                      0.47 kB │ gzip:   0.34 kB
dist/client/assets/ErrorBoundary-DwultlP_.js                              2.57 kB │ gzip:   1.07 kB
dist/client/assets/index-uD9RfciL.js                                      4.49 kB │ gzip:   2.04 kB
dist/client/assets/jsx-dev-runtime-Czb3f8pQ.js                            5.59 kB │ gzip:   2.43 kB
dist/client/assets/index-BlGQAcOD.js                                     20.72 kB │ gzip:   7.43 kB
dist/client/assets/index-tKuM8enU.js                                     60.91 kB │ gzip:  18.93 kB
dist/client/assets/App-BX7fcmDN.js                                      268.75 kB │ gzip:  90.08 kB
dist/client/assets/client-BlQxAbrl.js                                   364.36 kB │ gzip: 109.26 kB
✓ built in 2.54s

> frontend@0.0.0 build:server
> vite build --ssr src/entry-server.tsx --outDir dist/server

vite v6.4.2 building SSR bundle for production...
transforming...
✓ 1 modules transformed.
rendering chunks...
dist/server/entry-server.js  0.53 kB
✓ built in 56ms

> frontend@0.0.0 postbuild
> node scripts/apply-security-headers.cjs

apply-security-headers: wrote dist/client/_headers and injected CSP meta (4 inline script hashes)
----------------------------------------------------------------
### EXIT: 0
```

### backend selftest
```text
### COMMAND: /workspaces/scripts/with-node24.sh npm run selftest
### CWD: /workspaces/backend
### DATE: 2026-07-16T04:04:15Z
----------------------------------------------------------------

> selftest
> node scripts/selftest.cjs

PASS  chains.listPublic omits rpcEnv/url
PASS  every chain has an rpcEnv name
PASS  address-guard forces K3
PASS  address-guard rejects override keys
PASS  trace keys are opaque digests
PASS  anti-abuse limits cover required actions

selftest: 6/6 passed
----------------------------------------------------------------
### EXIT: 0
```

### backend drift:scan
```text
### COMMAND: /workspaces/scripts/with-node24.sh npm run drift:scan
### CWD: /workspaces/backend
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------

> drift:scan
> node scripts/drift-scan.cjs

drift:scan: clean (101 source files scanned)
----------------------------------------------------------------
### EXIT: 0
```

### backend verify:artifact
```text
### COMMAND: /workspaces/scripts/with-node24.sh npm run verify:artifact
### CWD: /workspaces/backend
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------

> verify:artifact
> node scripts/obfuscation-equivalence.cjs

obfuscation-equivalence: clean and build agree (27 tokens preserved)
----------------------------------------------------------------
### EXIT: 0
```

## 5. Full exact verifier outputs

### v01-ui-baseline
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-ui-baseline.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS PROGRESS_LABELS is exactly the 5 canonical labels in order
PASS neutral K3 copy present (mechanics hidden)
PASS no forbidden mechanics vocabulary appears in exported UI strings
PASS safeLabel() redacts forbidden mechanics terms at runtime
PASS App.tsx imports PROGRESS_LABELS + HUMAN_ROUTE_MSG from uiLabels
PASS App.tsx does NOT hardcode a divergent progress-label array

verify-ui-baseline: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v02-no-drift
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-no-drift.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
    [scan] 157 active files, 81 classified hits, 0 unclassified
PASS  ACTION type string matches contract
PASS  AUTHORIZE type string matches contract
PASS  EIP-712 domain is SecureGate / version 1
PASS  helpers import only ethers (+ type QueueKind)
PASS  deploy route rejects k2SessionKey + all key fields
PASS  no signTypedData / private-key signing in backend runtime
PASS  no forbidden old-ABI method names in helpers/UI
PASS  K2 helper never reads a k2 private key
PASS  UI collects K2 signature + addresses, not K2/K3 keys
PASS  K2 helper rejects the all-zero signature
PASS  active-source drift scan (all hits classified)
PASS  no active provenance drift (SecureGate is not an EIP-712 project)
PASS  required provenance wording present in active docs

verify-no-drift: 13/13 passed
----------------------------------------------------------------
### EXIT: 0
```

### v03-authgate-session
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-session.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS S04: fresh session is unbound with no K1 (fresh-per-use)
PASS S04: a gate must be blocked until a valid K1 is entered
PASS S04: binding K1 makes it session-bound and auto-fills downstream
PASS S04: a different K1 cannot silently overwrite a bound session
PASS S04: resetSession restores a clean unbound session (fresh-per-use)
PASS S05: SCAN is a same-device sweep that never verifies/unlocks
PASS S05: LINK DEVICE is a usb-linked-device sweep that never verifies/unlocks
PASS S06: 3 failed device attempts darken SCAN+LINK for that K1
PASS S06: passkey + human routes stay OPEN after device lockout
PASS S06: a success clears failures; a new K1 resets the counter (per-K1)

verify-authgate-session: 10 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v04-authgate-sweep
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-sweep.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS SCAN is a same-device sweep
PASS LINK DEVICE is a usb-linked-device sweep
PASS neither sweep ever verifies or unlocks execution
PASS sweep module has NO asset-movement surface (no transfer/queue/execute/sign/broadcast)

verify-authgate-sweep: 4 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v05-authgate-attempt-limits
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-attempt-limits.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS MAX_DEVICE_ATTEMPTS is 3
PASS 3 failed device attempts darken SCAN+LINK for that K1
PASS passkey + human routes stay OPEN after lockout; recovery never capped
PASS per-K1 counter: a different K1 resets; success clears

verify-authgate-attempt-limits: 4 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v06-device-breadcrumb
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-device-breadcrumb.cjs
### CWD: /workspaces/backend
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS S04: canonical trace events include all required names
PASS S04: every trace event has an explicit TTL window
PASS S04: breadcrumbs NEVER limit 2FA
PASS S04: recordEvent uses the event TTL and rejects unknown events
PASS S07: trace key is opaque (no raw subject material)
PASS S07: repeated breadcrumbs increment a coarse count
PASS S07: crossing the repeat threshold sets flagged=true (signal only)
PASS S07: distinct subjects do not collide
PASS S07: /api/trace route exists and uses anti-abuse + trace-store

verify-device-breadcrumb: 9 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v07-authgate-passkey
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-authgate-passkey.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:16Z
----------------------------------------------------------------
PASS PASSKEY input + ENTER button render below LINK DEVICE
PASS passkey lane stays enabled while SCAN/LINK are darkened (devicesLocked)
PASS register stores ONLY a salted digest (raw passkey never persisted)
PASS correct passkey verifies; mismatch fails closed
PASS passkey is K1-bound, not per-chain (digest keyed on K1 only)
PASS client wrapper treats a verified passkey as human-route signal ONLY

verify-authgate-passkey: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v08-admin-passkey
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-admin-passkey.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS route mints a K1-BOUND passkey (not per-chain)
PASS route honestly reports disabled when ADMIN_KEY is unset (no fake success)
PASS admin key constant-time compared and never stored/echoed
PASS minted passkey registered to the K1-bound passkey store
PASS client wrapper posts once and reports disabled honestly
PASS compact black-circle panel only — NO admin tabs / relay / operator console / revoke / veil
PASS App wires the admin mint via generateAdminPasskeyRemote

verify-admin-passkey: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v09-2fa-no-limits
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-2fa-no-limits.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS S10: 2FA reports NO recovery limit
PASS S10: 2FA NEVER requires a private key
PASS S10: 2FA NEVER gates/unlocks execution
PASS S10: 2FA is proactive + not active yet (honest, no fake success)
PASS S10: App.tsx renders honest 2FA status via twoFactorStatus()

verify-2fa-no-limits: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v10-recovery-flow-ui
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-recovery-flow-ui.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS recovery form exposes burner deployer key + compromised K1 key fields
PASS deployer + K1 keys are scrubbed immediately after signing
PASS K2/K3 are PUBLIC address fields — no K2/K3 private-key fields
PASS chain dropdown shows chain NAMES only (no rpc URL rendered)
PASS no public frontend RPC URLs anywhere in App
PASS funding estimate goes through the backend funding route
PASS no fake estimate / no production-ready label

verify-recovery-flow-ui: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v11-funding-gas
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-funding-gas.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS funding route exists at GET /api/funding/:chain
PASS funding estimate uses backend RPC (chains.rpcUrlFor)
PASS funding response returns NO rpc endpoint URL
PASS funding computes a real gas estimate (eth_gasPrice * gas)
PASS funding estimate is not a fabricated constant string
PASS client reaches gas/funding data through backend routes only (no direct provider URL)
PASS client funding path carries no private-key material

verify-funding-gas: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v12-recovery-cleanup-sweep
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-recovery-cleanup-sweep.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS freshScratch() starts with both secrets blank
PASS scrub() wipes both secrets in place
PASS FORBIDDEN_BACKEND_KEYS covers every session secret name
PASS isBackendSafe rejects any key-shaped field
PASS backendDeployBody yields signedTx ONLY

verify-recovery-cleanup-sweep: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v13-blacklist-k3
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-blacklist-k3.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS contract executes ONLY to K3 (transfer targets K3, never a param)
PASS contract captures a non-K3 destination as suspect (blacklist), never routes it
PASS K3 is immutable in the contract
PASS backend guard keeps forcedDestination == K3 even when override requested
PASS backend guard rejects override-smuggling body keys
PASS frontend mirror always returns K3 with neutral copy

verify-blacklist-k3: 6 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v14-k3-execution-sweep
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-k3-execution-sweep.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS resolveSweepTarget targets K3 when no override is present
PASS resolveSweepTarget IGNORES a requested override, still targets K3
PASS sweepTargetsOnlyK3 is true with an override attempt
PASS sweepTargetsOnlyK3 is true with no override
PASS no asset-movement primitive is exported by the sweep module

verify-k3-execution-sweep: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v15-k2-intent-builders
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-k2-intent-builders.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:17Z
----------------------------------------------------------------
PASS  anvil chainId matches contract GATE_CHAIN_ID
PASS  ERC20: client intentHash == on-chain computeIntentHash
PASS  ERC20: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC20: client verify recovers K2
PASS  ERC20: contract accepts authorizeIntent with the K2 sig
PASS  ERC20: wrong expected-K2 => valid=false
PASS  ERC20: wrong chainId => not K2
PASS  ERC20: wrong verifyingContract => not K2
PASS  ERC20: wrong intentHash => not K2
PASS  ERC721: client intentHash == on-chain computeIntentHash
PASS  ERC721: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC721: client verify recovers K2
PASS  ERC721: contract accepts authorizeIntent with the K2 sig
PASS  ERC721: wrong expected-K2 => valid=false
PASS  ERC721: wrong chainId => not K2
PASS  ERC721: wrong verifyingContract => not K2
PASS  ERC721: wrong intentHash => not K2
PASS  ERC1155: client intentHash == on-chain computeIntentHash
PASS  ERC1155: EIP-712 digest == on-chain computeAuthorizationDigest
PASS  ERC1155: client verify recovers K2
PASS  ERC1155: contract accepts authorizeIntent with the K2 sig
PASS  ERC1155: wrong expected-K2 => valid=false
PASS  ERC1155: wrong chainId => not K2
PASS  ERC1155: wrong verifyingContract => not K2
PASS  ERC1155: wrong intentHash => not K2
PASS  rejects empty signature
PASS  rejects all-zero 65-byte signature
PASS  rejects malformed-length signature
PASS  computeClientIntentHash rejects zero token
PASS  computeClientIntentHash rejects zero verifyingContract
PASS  ACTION_TYPEHASH matches contract type string
PASS  AUTHORIZE_TYPEHASH matches contract type string

verify-k2-intent-builders: 32/32 passed
----------------------------------------------------------------
### EXIT: 0
```

### v16-wallet-k2-flow
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-wallet-k2-flow.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:20Z
----------------------------------------------------------------
PASS provider unavailable returns K2 signer not connected
PASS injected typed-data signing path verifies K2
PASS injected payload matches canonical K2 helper digest
PASS pasted signature fallback verifies K2
PASS wrong K2 rejected
PASS wrong chainId rejected
PASS wrong verifyingContract rejected
PASS wrong intentHash rejected
PASS empty signature rejected
PASS all-zero signature rejected
PASS malformed signature rejected
PASS no K2 private key enters payload
PASS no server-side K2 signing

13/13 passed
----------------------------------------------------------------
### EXIT: 0
```

### v17-front-back-wiring
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:20Z
----------------------------------------------------------------
PASS App imports from ./lib/uiLabels and uses UI_PROGRESS_LABELS
PASS App imports from ./lib/deviceBreadcrumb and uses pingDevice
PASS App imports from ./lib/passkeyAccess and uses verifyPasskey
PASS App imports from ./lib/adminPasskey and uses generateAdminPasskeyRemote
PASS App imports from ./lib/twoFactorProactive and uses twoFactorStatus
PASS App imports from ./lib/k3Enforcement and uses enforceK3
PASS App imports from ./lib/recoveryCleanupSweep and uses isBackendSafe
PASS App imports from ./lib/k3ExecutionSweep and uses sweepTargetsOnlyK3
PASS App imports from ./lib/thankYouEnvelope and uses thankYouIsNotK3
PASS App broadcast() fails closed on key-bearing payloads (isBackendSafe guard)
PASS App execute path enforces K3 before broadcasting
PASS backend route exists: /api/trace
PASS backend route exists: /api/passkeys
PASS backend route exists: /api/admin-passkey
PASS backend route exists: /api/funding
PASS backend route exists: /api/deploy
PASS backend route exists: /api/anti-abuse
PASS backend route exists: /api/thank-you
PASS backend route exists: /api/chains
PASS backend route exists: /api/rpc

verify-front-back-wiring: 20 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v18-thank-you-envelope
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-thank-you-envelope.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:20Z
----------------------------------------------------------------
PASS thankYouIsNotK3 blocks a thank-you address equal to K3
PASS thank-you config exposes copyAddress as copy-only (no destination role)
PASS App uses thankYouIsNotK3 guard before copying the tip address
PASS thank-you address is NOT wired into any deploy/proof/execution body
PASS backend thank-you route is honest-capability (disabled unless configured)

verify-thank-you-envelope: 5 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v19-contract-obfuscation-layers
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-contract-obfuscation-layers.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS canonical Foundry artifact exists and carries real bytecode
PASS no fabricated / placeholder obfuscated artifact is committed
PASS source honestly documents the missing layer (no false completeness claim)
SKIPPED: no obfuscated build configured
NOTE: Contract/dashboard obfuscation is NOT complete.

verify-contract-obfuscation-layers: 3 passed, 0 failed (obfuscation build SKIPPED)
----------------------------------------------------------------
### EXIT: 0
```

### v20-obfuscation-ci
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-obfuscation-ci.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
SKIPPED: no obfuscated build configured
(A token-equivalence guard exists at backend/scripts/obfuscation-equivalence.cjs, but no obfuscation TOOL + build output is configured, so obfuscation CI is not claimed complete.)
----------------------------------------------------------------
### EXIT: 0
```

### v21-anti-abuse-downloads
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-anti-abuse-downloads.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS anti-abuse limits include dashboard_download and dashboard_ping
PASS repeated downloads eventually flag (breadcrumb count crosses threshold)
PASS anti-abuse record() eventually disallows beyond the max window
PASS trace key is opaque — a raw subject is NOT recoverable from it
PASS canonical event vocabulary excludes 2FA (breadcrumbs never limit 2FA)
PASS recordEvent rejects an unknown event (fail closed)
PASS trace route stores NO raw subject (reduces to bucketKey before recording)

verify-anti-abuse-downloads: 7 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

### v22-placeholder-gates
```text
### COMMAND: /workspaces/scripts/with-node24.sh node scripts/verify-placeholder-gates.cjs
### CWD: /workspaces
### DATE: 2026-07-16T04:04:21Z
----------------------------------------------------------------
PASS gate "scan" returns verified:false and cannot unlock
PASS gate "link" returns verified:false and cannot unlock
PASS gate "passkey" returns verified:false and cannot unlock
PASS gate "admin" returns verified:false and cannot unlock
PASS gate "twofa" returns verified:false and cannot unlock
PASS no gate message claims success/verified/unlocked/complete
PASS canExecuteIntent(false, []) === false (no K2 sig)
PASS canExecuteIntent(true, []) === true (K2 sig verified)
PASS any pile of honest placeholders cannot unlock when K2 unverified
PASS honest placeholders do not block a genuine K2-verified execution
PASS forged verified:true placeholder is rejected by canExecuteIntent
PASS forged unlocksExecution:true placeholder is rejected
PASS isPlaceholderResult guard rejects forged / verified objects
PASS PENDING_PLACEHOLDER_LAYERS lists all five hard placeholder layers
PASS PLACEHOLDER_GATE_MESSAGES defines all five gate kinds
PASS placeholderGates.ts contains no "verified: true" (code, comments stripped)
PASS placeholderGates.ts contains no "unlocksExecution: true" (code)
PASS placeholderGates.ts performs no network/credential/key operations
PASS App.tsx imports the placeholder honesty gates
PASS App.tsx has no private MSG placeholder map (single source of truth)
PASS App.tsx gates executeIntent through canExecuteIntent(authVerified, …)

placeholder-gates: 21 passed, 0 failed
----------------------------------------------------------------
### EXIT: 0
```

## 6. Raw drift scan + classification

**Command:** `bash scripts/drift-scan-raw.sh`

**Raw output (46 lines):**
```text
scripts/verify-browser-builders.cjs:76:    const bad = abi.concat([{ type: 'function', name: 'queueIntent', inputs: [{ type: 'bytes32' }, { type: 'bytes' }], outputs: [], stateMutability: 'nonpayable' }]);
scripts/verify-browser-builders.cjs:135:    for (const bad of ['queueIntent', 'forwardERC20', 'computeEIP712Digest', 'domainSeparator']) {
scripts/verify-no-drift.cjs:87:  for (const bad of ['queueIntent', 'forwardERC20', 'computeEIP712Digest', 'domainSeparator']) {
scripts/e2e-local-securegate.cjs:28:const PORT = 8900 + (process.pid % 300);
scripts/e2e-testnet-securegate.cjs:19://   TESTNET_K1_PRIVATE_KEY
scripts/e2e-testnet-securegate.cjs:20://   TESTNET_K2_PRIVATE_KEY   (or TESTNET_K2_SIGNER_MODE=external)
scripts/e2e-testnet-securegate.cjs:42:  const k1 = env('TESTNET_K1_PRIVATE_KEY');
scripts/e2e-testnet-securegate.cjs:44:  const k2 = env('TESTNET_K2_PRIVATE_KEY');
scripts/verify-csp.cjs:59:  assert(!/operator|revoke|submitRevoke|X-Operator-Proof|\bQR\b|Flashbots|sweeper/i.test(moduleSrc),
scripts/verify-mobile-ci.cjs:63:  assert(!/\bRevoke\b/.test(app) && !/submitRevokeBundle|operator-proof-input|getOperatorProof/.test(app),
scripts/verify-ui-baseline.cjs:49:    for (const bad of ['revoke', 'flashbot', 'mempool', 'smoke-test', 'smoke test', 'sweeper bot']) {
scripts/verify-abi-canonical.cjs:40:const FORBIDDEN = ['queueIntent', 'forwardERC20', 'computeEIP712Digest', 'domainSeparator'];
scripts/verify-abi-canonical.cjs:56:    // domainSeparator() lowercase forbidden, but DOMAIN_SEPARATOR() required — guard exact case.
scripts/verify-abi-canonical.cjs:57:    if (bad === 'domainSeparator') assert(!sigs.includes('domainSeparator()'), 'lowercase domainSeparator present');
scripts/verify-admin-passkey.cjs:48:  assert(!/operator-proof-input|submitRevokeBundle|getOperatorProof|OPERATOR_VEIL_PHRASE|X-Operator-Proof/.test(app), 'operator surface present');
scripts/verify-blacklist-k3.cjs:54:    assert(guardMod.hasForbiddenOverride({ overrideDestination: '0xabc' }) === true, 'overrideDestination not caught');
scripts/verify-blacklist-k3.cjs:55:    assert(guardMod.hasForbiddenOverride({ k2OverrideDest: '0xabc' }) === true, 'k2OverrideDest not caught');
scripts/drift-scan-raw.sh:7:"queueIntent\|forwardERC20\|computeEIP712Digest\|domainSeparator\|operator-proof-input\|submitRevokeBundle\|submit-revoke-bundle\|getOperatorProof\|/api/recovery/execute\|/api/credentials\|/api/revoke\|/api/queue\|/api/authorize\|/api/execute\|OPERATOR_VEIL_PHRASE\|X-Operator-Proof\|Flashbots\|flashbots\|smoke test\|SMOKE TEST\|sweeper bot\|DEPLOYMENT BUNDLE\|overrideDestination\|overrideDest\|k2OverrideDest\|K1_PRIVATE_KEY\|DEPLOYER_PRIVATE_KEY\|K2_PRIVATE_KEY\|K3_PRIVATE_KEY\|TESTNET_K2_PRIVATE_KEY\|SECUREGATE_BYTECODE=\|SECUREGATE_ABI=\|MIN_DELAY\|900" \
scripts/gen-battery-handoff.py:41:     "Preserve UI_FRONTEND_SPECS shell; no operator/revoke/QR/Flashbots vocab in UI.",
scripts/gen-battery-handoff.py:45:     "New ABI only (queueERC20/authorizeIntent/executeIntent...); forbid queueIntent/forwardERC20/computeEIP712Digest/domainSeparator.",
scripts/gen-battery-handoff.py:97:     "All 900s are abuse TTL/window, NOT a K1->K2 cooldown; MIN_DELAY absent.",
scripts/gen-battery-handoff.py:112: ("900-second K1->K2 cooldown added","no","PASS","drift scan: no MIN_DELAY; 900s only in anti-abuse-kv/trace-store TTL"),
scripts/gen-battery-handoff.py:113: ("900-second values only abuse TTL/window if present","yes","PASS","backend/lib/anti-abuse-kv.js windowSec:900 / trace-store.js ttlSec:900"),
scripts/gen-battery-handoff.py:138: ("scripts/verify-browser-builders.cjs","verifier assertion","builds a bad ABI containing queueIntent to prove the guard rejects it"),
scripts/gen-battery-handoff.py:140: ("scripts/verify-abi-canonical.cjs","verifier assertion","FORBIDDEN list + lowercase domainSeparator guard"),
scripts/gen-battery-handoff.py:141: ("scripts/verify-csp.cjs","verifier assertion","asserts operator/revoke/Flashbots/sweeper absent from module"),
scripts/gen-battery-handoff.py:142: ("scripts/verify-mobile-ci.cjs","verifier assertion","asserts Revoke/submitRevokeBundle/operator-proof absent"),
scripts/gen-battery-handoff.py:143: ("scripts/verify-ui-baseline.cjs","verifier assertion","forbidden UI vocab list (revoke/flashbot/smoke test/sweeper bot)"),
scripts/gen-battery-handoff.py:145: ("scripts/verify-blacklist-k3.cjs","verifier assertion","asserts guard catches overrideDestination/k2OverrideDest"),
scripts/gen-battery-handoff.py:147: ("scripts/e2e-local-securegate.cjs","local-only test harness","'8900' port math; '900' is a coincidental substring, not MIN_DELAY"),
scripts/gen-battery-handoff.py:148: ("scripts/e2e-testnet-securegate.cjs","local-only test harness","TESTNET_K1/K2_PRIVATE_KEY read by a LOCAL testnet script only, never backend runtime"),
scripts/gen-battery-handoff.py:150: ("backend/.env.securegate","coincidental substring","'900' occurs inside the compiled bytecode hex value; non-runnable literal"),
scripts/gen-battery-handoff.py:151: ("backend/lib/anti-abuse-kv.js","abuse TTL/window only","windowSec:900 rate-limit windows (auth/link/passkey/deploy), NOT a K1->K2 cooldown"),
scripts/gen-battery-handoff.py:152: ("backend/lib/trace-store.js","abuse TTL/window only","ttlSec:900 breadcrumb event TTLs, NOT a K1->K2 cooldown"),
scripts/gen-battery-handoff.py:156: ("frontend/src/entry-client.tsx","coincidental substring","Lato font weight 900 (@fontsource/lato/900.css)"),
scripts/gen-battery-handoff.py:157: ("frontend/src/index.css","coincidental substring","--neutral-900 color token and font-weight:900"),
scripts/gen-battery-handoff.py:160: ("docs/kv.md","docs warning","ttlSec:900 shown in a KV usage example"),
scripts/gen-battery-handoff.py:241:w("\n**Result:** 0 active runnable forbidden paths. `MIN_DELAY` absent everywhere; every")
scripts/gen-battery-handoff.py:242:w("`900` is an abuse TTL/window, a coincidental substring (font weight / CSS token / bytecode hex),")
backend/.env.example:55:TESTNET_K1_PRIVATE_KEY=
backend/.env.example:56:TESTNET_K2_PRIVATE_KEY=
backend/lib/anti-abuse-kv.js:12:  auth_gate_attempt:  { max: 3,   windowSec: 900 },
backend/lib/anti-abuse-kv.js:13:  link_device_attempt:{ max: 3,   windowSec: 900 },
backend/lib/anti-abuse-kv.js:14:  passkey_verify:     { max: 10,  windowSec: 900 },
backend/lib/anti-abuse-kv.js:16:  deploy_broadcast:   { max: 5,   windowSec: 900 },
backend/lib/address-guard.js:57:const FORBIDDEN_OVERRIDE_KEYS = ['overrideDestination', 'overrideDest', 'k2OverrideDest'];
backend/lib/trace-store.js:27:  authgate_scan_start:        { ttlSec: 900 },
backend/lib/trace-store.js:28:  authgate_scan_fail:         { ttlSec: 900 },
backend/lib/trace-store.js:29:  authgate_scan_success:      { ttlSec: 900 },
backend/lib/trace-store.js:30:  link_device_start:          { ttlSec: 900 },
backend/lib/trace-store.js:31:  link_device_fail:           { ttlSec: 900 },
backend/lib/trace-store.js:32:  passkey_fail:               { ttlSec: 900 },
backend/.env.securegate:1:SECUREGATE_BYTECODE_HEX=0x61014034620002c857601f62001b7638819003918201601f19168301926001600160401b039290918385118386101762000262578160609284926040978852833981010312620002c8576200005481620002e8565b9062000070846200006860208401620002e8565b9201620002e8565b916001600160a01b0380821680158015620002bd575b8015620002b2575b620002a1578184169182821492831562000294575b50821562000287575b5050620002765760805260a05260c0524660e05261010091308352600a60208251620000d881620002cc565b82815201695365637572654761746560b01b81522090600160208251620000ff81620002cc565b82815201603160f81b8152209080519160208301937f8b73c3c69bb8fe3d512ecc4cf759cc79239f7b179b0ffacaa9a75d522b39400f85528284015260608301524660808301523060a083015260a0825260c08201938285109085111762000262578390525190206101209081526118789283620002fe84396080518381816101e3015281816104680152818161087601528181610bf001528181610d8d0152611216015260a051838181610340015261113a015260c05183818161051f015281816107d50152818161092c01528181610b9a01528181610c7101528181610e5e01528181610eab01528181610fb301528181611056015281816112cd0152611741015260e05183818161014d015281816105540152818161080c0152818161096101528181611302015261176801525182818161025501528181610492015281816108a001528181610db7015261124001525181818161118001526117c80152f35b634e487b7160e01b5f52604160045260245ffd5b845163e6c4247b60e01b8152600490fd5b85161490505f80620000ac565b8682161492505f620000a3565b865163e6c4247b60e01b8152600490fd5b50818516156200008e565b508184161562000086565b5f80fd5b604081019081106001600160401b038211176200026257604052565b51906001600160a01b0382168203620002c85756fe60806040818152600480361015610020575b505050361561001e575f80fd5b005b5f9260e05f35811c91826301ffc9a71461153257508163150b7a02146114dd5781632a513df6146111df57816334b98663146111a35781633644e515146111695781635b3b06ae146111265781637a1c9ca714610d6a5781639021578a14610cd0578163928335aa14610ca8578163a379879214610bc9578163a3ec761d14610b84578163bc197c8114610af9578163bdf0158b14610855578163bf9eafd614610764578163d9a2397c1461044957508063e6234ce914610212578063e89f8be7146101ce578063f23a6e6114610174578063f7c69946146101355763feb61724036100115734610131576020366003190112610131578160209360ff923581526001855220541690519015158152f35b8280fd5b505034610170578160031936011261017057602090517f00000000000000000000000000000000000000000000000000000000000000008152f35b5080fd5b5091346101cb5760a03660031901126101cb5761018f61159c565b506101986115b2565b506084359067ffffffffffffffff82116101cb57506020926101bc913691016115c8565b50505163f23a6e6160e01b8152f35b80fd5b505034610170578160031936011261017057517f00000000000000000000000000000000000000000000000000000000000000006001600160a01b03168152602090f35b50903461013157806003193601126101315781359160243567ffffffffffffffff81116104455761024690369083016115c8565b90929091906001600160a01b037f000000000000000000000000000000000000000000000000000000000000000081163003610437578587528660205281872093600585019586549560ff8760101c16156104275760ff87166104175785015442116104075760416102b7896116d8565b92036103f757602081013590848101358a1a7f7fffffffffffffffffffffffffffffff5d576e7357a4501ddfe92f46681b20a083116103bd57601b81106103d8575b60ff16601b811415806103cd575b6103bd57928a926080926020958851938452868401523587830152606082015282805260015afa156103b357808751169081156103a4577f0000000000000000000000000000000000000000000000000000000000000000160361039757505060ff191660011790557f51ea2bb1b1eb3a90ff36f8b9bf18bcfe1eb21cb76a39f0f8eebc52276df1f8ea8280a280f35b51635cd5d23360e01b8152fd5b505051635cd5d23360e01b8152fd5b81513d88823e3d90fd5b8551635cd5d23360e01b81528790fd5b50601c811415610307565b601b0160ff8111156102f957634e487b7160e01b8b526011875260248bfd5b50505051635cd5d23360e01b8152fd5b50505051631da7447960e21b8152fd5b845163ea8e4eb560e01b81528690fd5b845163350f7c5d60e01b81528690fd5b5051632b90e4eb60e11b8152fd5b8480fd5b90508284346101cb575061045c36611648565b946001600160a01b03937f00000000000000000000000000000000000000000000000000000000000000008516330361075457847f0000000000000000000000000000000000000000000000000000000000000000163003610744578416938415610734578215801561071f575b61070f57428711156106ff57825f52600192602098848a52875f208560ff198254161790558751928a8401905f805160206118238339815191528252868a8601528860608601528760808601528660a08601527f00000000000000000000000000000000000000000000000000000000000000001660c08501528285850152610100938a858201527f00000000000000000000000000000000000000000000000000000000000000006101208201526101403081830152815261058c816116bb565b51902098895f525f8b5260ff60058a5f20015460101c166106f05790899392918951926105b88461169e565b8784528c8085018b81528c8601908b82525f60608801938c85526080890195865260a0890196875260c089019b828d52890199828b5289019a8d8c528252528d5f2096519060038210156106dd57958f9c9996957ff58f445bb2ee96ff2af3d7987adf343a0cd4246d5e0ff3504f21ef6c4a61630a9c9995610699956005958b9560609f9c9a60ff6106b09c5491610100600160a81b03905160081b169216906affffffffffffffffffffff60a81b1617178655518c86015551600285015551600384015551908201550194511515859060ff801983541691151516179055565b51835461ff00191690151560081b61ff0016178355565b51151562ff000082549160101b169062ff000019161790558651918183528983015286820152a351908152f35b602187634e487b7160e01b5f525260245ffd5b5087516301d761cd60e71b8152fd5b8551631da7447960e21b81528890fd5b8551633ab3447f60e11b81528890fd5b50825f52600160205260ff865f2054166104ca565b855163e6c4247b60e01b81528890fd5b8551632b90e4eb60e11b81528890fd5b8551630780de2b60e41b81528890fd5b919050346108515760c03660031901126108515735906003821015610851576020935061078f6115b2565b908351916107b3868401945f805160206118238339815191528652868501906115f6565b6001600160a01b039081166060840152604435608084015260643560a08401527f00000000000000000000000000000000000000000000000000000000000000001660c08301526084359082015260a4356101008201527f000000000000000000000000000000000000000000000000000000000000000061012082015230610140808301919091528152610847816116bb565b5190209051908152f35b8380fd5b90508284346101cb575061086836611648565b9490926001600160a01b03907f00000000000000000000000000000000000000000000000000000000000000008216330361075457817f00000000000000000000000000000000000000000000000000000000000000001630036107445781169384156107345780158015610ae4575b61070f57428711156106ff57805f5260209760018952865f20600160ff19825416179055865192898401905f8051602061182383398151915282525f898601528760608601525f60808601528660a08601527f00000000000000000000000000000000000000000000000000000000000000001660c085015282858501526101009389858201527f000000000000000000000000000000000000000000000000000000000000000061012082015261014030818301528152610999816116bb565b51902097885f525f8a5260ff6005895f20015460101c16610ad55790889392918851926109c58461169e565b5f84528b8085018a81528b8601905f82525f60608801938c85526080890195865260a0890196875260c089019b828d52890199828b5289019a60018c528252528c5f2096519060038210156106dd5795610aa7958f9c9995610699956005958b957ff58f445bb2ee96ff2af3d7987adf343a0cd4246d5e0ff3504f21ef6c4a61630a9f9c9b60609f9c60ff905491610100600160a81b03905160081b169216906affffffffffffffffffffff60a81b161717865551600186015551600285015551600384015551908201550194511515859060ff801983541691151516179055565b51151562ff000082549160101b169062ff000019161790558551905f82525f8983015286820152a351908152f35b5086516301d761cd60e71b8152fd5b50805f52600160205260ff865f2054166108d8565b505091346101cb5760a03660031901126101cb57610b1561159c565b50610b1e6115b2565b5067ffffffffffffffff9060443582811161017057610b409036908601611617565b505060643582811161017057610b599036908601611617565b50506084359182116101cb5750602092610b75913691016115c8565b50505163bc197c8160e01b8152f35b50505034610170578160031936011261017057517f00000000000000000000000000000000000000000000000000000000000000006001600160a01b03168152602090f35b5050903461013157602036600319011261013157610be561159c565b6001600160a01b03927f000000000000000000000000000000000000000000000000000000000000000084163303610c9a57508216918215159081610c6d575b50610c2e578280f35b81835260026020528220805460ff191660011790557fb921dd23d8fec108339f59caa15a8b090534624dcd51ad6b0b4dee50830c44578280a25f808280f35b90507f0000000000000000000000000000000000000000000000000000000000000000168214155f610c25565b8251630780de2b60e41b8152fd5b505091346101cb5760203660031901126101cb5750610cc9602092356116d8565b9051908152f35b8493915034610851576020366003190112610851579060ff9181610120958535815280602052208054946001820154600283015490600560038501549385015494015495805198610d238a8a83166115f6565b60018060a01b039060081c1660208a01528801526060870152608086015260a0850152828216151560c0850152828260081c1615159084015260101c161515610100820152f35b505090346110c5576020806003193601126110c5578235926001600160a01b03927f00000000000000000000000000000000000000000000000000000000000000008416330361111957837f000000000000000000000000000000000000000000000000000000000000000016300361110c57845f525f8352805f209260058401805460ff8160101c16156110fc5760ff8116156110ec5760ff8160081c166110dc578486015442116104075761ff001916610100179055835460ff811660038110156110c95788919080610f6e5750508186865460081c16604460028801548651948593849263a9059cbb60e01b84528c7f0000000000000000000000000000000000000000000000000000000000000000168b85015260248401525af1918215610f64578892610f00575b505015610ef357505081905b5460081c16907f000000000000000000000000000000000000000000000000000000000000000016917f39deaa45521a4e58b54c29b5d9dc173edfd7134ce60aeb4bb3047f39fed9ba4e8480a480f35b516312171d8360e31b8152fd5b809192503d8211610f5d575b601f8101601f1916830167ffffffffffffffff811184821017610f4a578452820182900312610f4657518015158103610f46575f80610e97565b8680fd5b604186634e487b7160e01b5f525260245ffd5b503d610f0c565b83513d8a823e3d90fd5b6001919294989796959350145f14611018575083835460081c16906001840154823b156108515760648492838a519586948593632142170760e11b855230908501528a7f000000000000000000000000000000000000000000000000000000000000000016602485015260448401525af1801561100e5784959650610ff5575b5050610ea3565b61100191929350611676565b610851578190845f610fee565b86513d84823e3d90fd5b6001840154600285015496979596949593509060081c8616803b156110c5575f928360c49286519788958694637921219560e11b865230908601528b7f00000000000000000000000000000000000000000000000000000000000000001660248601526044850152606484015260a060848401528160a48401525af19081156110bc57506110a9575b508190610ea3565b6110b4919450611676565b5f92816110a1565b513d5f823e3d90fd5b5f80fd5b602185634e487b7160e01b5f525260245ffd5b50505051630dc1019760e01b8152fd5b5050505163ea8e4eb560e01b8152fd5b5050505163350f7c5d60e01b8152fd5b51632b90e4eb60e11b8152fd5b51630780de2b60e41b8152fd5b83346110c5575f3660031901126110c557517f00000000000000000000000000000000000000000000000000000000000000006001600160a01b03168152602090f35b83346110c5575f3660031901126110c557602090517f00000000000000000000000000000000000000000000000000000000000000008152f35b83346110c55760203660031901126110c5576020906001600160a01b036111c861159c565b165f526002825260ff815f20541690519015158152f35b905082346110c55760a03660031901126110c5576111fb61159c565b608435926064359160243591604435916001600160a01b03907f0000000000000000000000000000000000000000000000000000000000000000821633036114cd57817f00000000000000000000000000000000000000000000000000000000000000001630036114bd5781169485156114ad5780158015611498575b611488574288111561147857805f5260209860018a52875f20600160ff198254161790558751928a8401905f80516020611823833981519152825260028a8601528860608601528760808601528660a08601527f00000000000000000000000000000000000000000000000000000000000000001660c08501528285850152610100938a858201527f00000000000000000000000000000000000000000000000000000000000000006101208201526101403081830152815261133a816116bb565b51902098895f525f8b5260ff60058a5f20015460101c166106f05790899392918951926113668461169e565b600284528c8085018b81528c8601908b82525f60608801938c85526080890195865260a0890196875260c089019b828d52890199828b5289019a60018c528252528d5f2096519060038210156106dd57958f9c9996957ff58f445bb2ee96ff2af3d7987adf343a0cd4246d5e0ff3504f21ef6c4a61630a9c9995610699956005958b9560609f9c9a60ff61144a9c5491610100600160a81b03905160081b169216906affffffffffffffffffffff60a81b161717865551600186015551600285015551600384015551908201550194511515859060ff801983541691151516179055565b51151562ff000082549160101b169062ff00001916179055865191600283528983015286820152a351908152f35b8651631da7447960e21b81528990fd5b8651633ab3447f60e11b81528990fd5b50805f52600160205260ff875f205416611278565b865163e6c4247b60e01b81528990fd5b8651632b90e4eb60e11b81528990fd5b8651630780de2b60e41b81528990fd5b8284346110c55760803660031901126110c5576114f861159c565b506115016115b2565b5060643567ffffffffffffffff81116110c557602092611523913691016115c8565b505051630a85bd0160e11b8152f35b83346110c55760203660031901126110c557359063ffffffff60e01b82168092036110c5576020916301ffc9a760e01b811490811561158b575b811561157a575b5015158152f35b630271189760e51b14905083611573565b630a85bd0160e11b8114915061156c565b600435906001600160a01b03821682036110c557565b602435906001600160a01b03821682036110c557565b9181601f840112156110c55782359167ffffffffffffffff83116110c557602083818601950101116110c557565b9060038210156116035752565b634e487b7160e01b5f52602160045260245ffd5b9181601f840112156110c55782359167ffffffffffffffff83116110c5576020808501948460051b0101116110c557565b60809060031901126110c5576004356001600160a01b03811681036110c55790602435906044359060643590565b67ffffffffffffffff811161168a57604052565b634e487b7160e01b5f52604160045260245ffd5b610120810190811067ffffffffffffffff82111761168a57604052565b610160810190811067ffffffffffffffff82111761168a57604052565b805f525f6020526040805f209160ff600584015460101c1615611811576003600484015493015482519360208501927fced0536620e4d38a74275fc3d0b4673ed04b0e5ec0f39b4f0ccc1ce1cce77f998452848601526060850152608084015260018060a01b037f00000000000000000000000000000000000000000000000000000000000000001660a08401527f000000000000000000000000000000000000000000000000000000000000000060c08401523060e084015260e0835261010083019167ffffffffffffffff918484108385111761168a578382528451902061190160f01b61012086019081527f00000000000000000000000000000000000000000000000000000000000000006101228701526101428601919091526042845293610180019182118383101761168a575251902090565b815163350f7c5d60e01b8152600490fdfe1e790325b92daad089ca88ea17825c13a8c87f5cb76de6433dae3642333c531da26469706673582212206ea7e68b99a4ea1bbfb13f16ecc1b5291865d9147ed64d0051494bbbcd57537664736f6c63430008180033
frontend/src/lib/uiLabels.ts:4:// forbidden operator vocabulary (the cancel-approval verb, bot, Flashbots, the
frontend/src/lib/securegateTxBuilder.ts:27:  'queueIntent',
frontend/src/lib/securegateTxBuilder.ts:28:  'forwardERC20',
frontend/src/lib/securegateTxBuilder.ts:29:  'computeEIP712Digest',
frontend/src/lib/securegateTxBuilder.ts:30:  'domainSeparator',
frontend/src/entry-client.tsx:1:// Self-hosted fonts (no runtime CDN dependency). Lato ships 400/700/900;
frontend/src/entry-client.tsx:5:import '@fontsource/lato/900.css'
frontend/src/index.css:132:  --neutral-900: #212121;
frontend/src/index.css:374:.sg-brand { font-weight: 900; letter-spacing: 0.06em; font-size: 14px; }
docs/browser-builders.md:44:`queueIntent`, `forwardERC20`, `computeEIP712Digest`, `domainSeparator`. It asserts
docs/e2e-testnet.md:19:| `TESTNET_K1_PRIVATE_KEY` | funded K1 key — **local script use only** |
docs/e2e-testnet.md:20:| `TESTNET_K2_PRIVATE_KEY` | K2 key, or set `TESTNET_K2_SIGNER_MODE=external` |
docs/kv.md:25:await kv.set('k', value, { ttlSec: 900 });
docs/kv.md:28:await kv.incr('count', { ttlSec: 900 });
```

**Classification (every hit).** Automated `verify-no-drift.cjs` independently reports
`0 unclassified` across 156 active files (section 5, v02). Manual mapping of the 46 raw hits:

| File | Category | Why it is not an active forbidden path |
|---|---|---|
| `scripts/verify-browser-builders.cjs` | verifier assertion | builds a bad ABI containing queueIntent to prove the guard rejects it |
| `scripts/verify-no-drift.cjs` | verifier assertion | forbidden old-ABI name list it asserts absent |
| `scripts/verify-abi-canonical.cjs` | verifier assertion | FORBIDDEN list + lowercase domainSeparator guard |
| `scripts/verify-csp.cjs` | verifier assertion | asserts operator/revoke/Flashbots/sweeper absent from module |
| `scripts/verify-mobile-ci.cjs` | verifier assertion | asserts Revoke/submitRevokeBundle/operator-proof absent |
| `scripts/verify-ui-baseline.cjs` | verifier assertion | forbidden UI vocab list (revoke/flashbot/smoke test/sweeper bot) |
| `scripts/verify-admin-passkey.cjs` | verifier assertion | asserts operator surface tokens absent |
| `scripts/verify-blacklist-k3.cjs` | verifier assertion | asserts guard catches overrideDestination/k2OverrideDest |
| `scripts/drift-scan-raw.sh` | redaction/blocklist only | the scanner's own forbidden-token pattern |
| `scripts/e2e-local-securegate.cjs` | local-only test harness | '8900' port math; '900' is a coincidental substring, not MIN_DELAY |
| `scripts/e2e-testnet-securegate.cjs` | local-only test harness | TESTNET_K1/K2_PRIVATE_KEY read by a LOCAL testnet script only, never backend runtime |
| `backend/.env.example` | local-only test harness | empty TESTNET_K*_PRIVATE_KEY= placeholders for the local e2e script; not runtime backend keys |
| `backend/.env.securegate` | coincidental substring | '900' occurs inside the compiled bytecode hex value; non-runnable literal |
| `backend/lib/anti-abuse-kv.js` | abuse TTL/window only | windowSec:900 rate-limit windows (auth/link/passkey/deploy), NOT a K1->K2 cooldown |
| `backend/lib/trace-store.js` | abuse TTL/window only | ttlSec:900 breadcrumb event TTLs, NOT a K1->K2 cooldown |
| `backend/lib/address-guard.js` | rejection list | FORBIDDEN_OVERRIDE_KEYS the guard strips/rejects |
| `frontend/src/lib/uiLabels.ts` | redaction/blocklist only | comment naming the forbidden operator vocabulary the UI must avoid |
| `frontend/src/lib/securegateTxBuilder.ts` | rejection list | forbidden old-ABI method names the builder refuses to emit |
| `frontend/src/entry-client.tsx` | coincidental substring | Lato font weight 900 (@fontsource/lato/900.css) |
| `frontend/src/index.css` | coincidental substring | --neutral-900 color token and font-weight:900 |
| `docs/browser-builders.md` | docs warning | documents the forbidden ABI names the verifier asserts absent |
| `docs/e2e-testnet.md` | docs warning | documents TESTNET_* keys as local-script-only |
| `docs/kv.md` | docs warning | ttlSec:900 shown in a KV usage example |

**Result:** 0 active runnable forbidden paths. `MIN_DELAY` absent everywhere; every
`900` is an abuse TTL/window, a coincidental substring (font weight / CSS token / bytecode hex),
or a docs example. Every private-key token is a rejection list, a verifier assertion, or a
local-only testnet script — never a backend-runtime key read.

## 7. ZIP / repo content proof

### Source ZIP / repo content proof — CURRENT DAPINK artifact

The authoritative, current source artifact is the **DAPINK-fixed** ZIP:

- current source ZIP: **`securegate-eip777g-dapink-final.zip`**
- current source SHA256: recorded in the sidecar **`securegate-eip777g-dapink-final.zip.sha256`**
  (the authoritative hash is the sidecar to avoid a circular self-reference, since this doc ships
  inside the source ZIP)
- built from git-tracked source + Foundry `out/` + the three dotfiles (`.node-version`, `.nvmrc`,
  `.npmrc`) + `scripts/verify-design-fidelity.cjs`; all `.zip` / `.sha256` / `.b64.txt` excluded;
  no `uploads/`, `outputs/`, `cache/`, `node_modules/`, `.git/`

**Acceptance gate on the current source ZIP:**

```
$ sha256sum securegate-eip777g-dapink-final.zip
$ cat securegate-eip777g-dapink-final.zip.sha256          # authoritative hash — must match
$ scripts/with-node24.sh node scripts/verify-zip-contents.cjs securegate-eip777g-dapink-final.zip
[PASS] standard ZIP central directory parsed
[PASS] all required active-root files present
[PASS] no uploads/, outputs/, restored-original-*, _stitch_zip/, node_modules/, or .git paths
[PASS] ZIP content gate satisfied
$ scripts/with-node24.sh node scripts/verify-design-fidelity.cjs
verify-design-fidelity: 29 passed, 0 failed
```

**Retrieval.** Primary artifact is `securegate-eip777g-dapink-final.zip`. Because the studio workspace
export can strip `.zip` and hidden dotfiles, a byte-identical base64 fallback is at
`securegate-eip777g-dapink-final.zip.b64.txt`. Reconstruct (skips `#` comment lines):

```
awk '!/^#/' securegate-eip777g-dapink-final.zip.b64.txt | base64 -d > securegate-eip777g-dapink-final.zip
sha256sum securegate-eip777g-dapink-final.zip                              # must equal the .sha256 sidecar
scripts/with-node24.sh node scripts/verify-zip-contents.cjs securegate-eip777g-dapink-final.zip   # [PASS] ZIP content gate satisfied
```

> **DEPRECATED / OLD ARTIFACTS — do not use, not current.**
> The previous source ZIP `securegate-eip777g-final.zip` (sha256 `198f0637…5f39a3`) and the previous
> handoff `securegate-eip777g-handoff.zip` (sha256 `be5073…ffce85`) are **stale for DAPINK**: they
> carried the Surf badge and lacked `scripts/verify-design-fidelity.cjs`. They are not part of this
> handoff and must not be built from.


## 8. Remaining missing pieces (honest)

- **Obfuscation:**
  ```
  SKIPPED: no obfuscated build configured
  Contract/dashboard obfuscation is NOT complete.
  ```
- **K2 wallet signing** is wired to an injected EIP-712 provider interface but not
  exercised against a real hardware/browser wallet in this environment.
- **Live on-chain deploy** is not exercised; the browser deploy builder only refines gas
  when a validated artifact is served.
- **Playwright E2E** config exists (`frontend/playwright.config.ts`) but a full headed run
  is not part of this battery.

## 9. Final status

No production-ready claim.