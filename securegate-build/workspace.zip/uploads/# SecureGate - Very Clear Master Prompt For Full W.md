# SecureGate - Very Clear Master Prompt For Full Wired Dashboard

## TL;DR

Use this prompt. It tells them exactly: **locked DAPINK baseline is restored, but that is not the finish line. Now prove or implement the full unlocked dashboard behind Auth-Gate.** It blocks them from giving only another locked screenshot or another design-only proof.

---

## Paste This Exactly

```txt
SECUREGATE / EIP-777G — COMPLETE WIRED DASHBOARD BEHIND DAPINK AUTH-GATE

This is NOT a design-restyle task.

The locked DAPINK baseline is already the visual target and must not be changed.

The actual remaining requirement is:

  Prove or complete the full wired SecureGate dashboard AFTER Auth-Gate unlock.

Do not confuse these two states:

  LOCKED / PRE-AUTH:
    Shows DAPINK Auth-Gate sidebar + STANDALONE OPERATION + CAUTION only.

  UNLOCKED / POST-AUTH:
    Shows the completed wired dashboard:
      Recovery
      Protection / 2FA
      Admin passkey flow
      Status
      funding/gas
      deploy/sign/broadcast flow
      progress labels
      thank-you section

A locked screenshot alone is not completion.

A design-fidelity verifier alone is not completion.

A build passing alone is not completion.

You must prove the dashboard is wired after unlock.

============================================================
0. SOURCE OF TRUTH
============================================================

Use the restored DAPINK source baseline as the starting point:

  securegate-eip777g-dapink-final.zip
  SHA256: ae82ea4f649b29fff20553b157bbcfc0ca509595e59a0efef210834468e8c66b

The supplied DAPINK screenshot is the locked/pre-auth visual target.

The corrected product behavior is in:

  securegate-dashboard (22).md

The UI design baseline is in:

  UI_FRONTEND_SPECS (6).md

But quarantine stale/unsafe UI spec language:
  - Production-Ready
  - public RPC URLs
  - Revoke
  - QR
  - operator/relay/admin-control drift
  - Flashbots
  - smoke test
  - sweeper/bot wording

Do not use the outer workspace wrapper ZIP as source.

Do not use uploads/ or outputs/ as implementation source.

If source changes after the ae82 baseline, produce a new source ZIP and new SHA256.

============================================================
1. LOCKED DAPINK BASELINE MUST REMAIN UNCHANGED
============================================================

Before Auth-Gate unlock, the UI must match the supplied DAPINK screenshot.

Locked/pre-auth screen must show:

  SECUREGATE
  EIP-777G
  pink SCRUB button
  yellow circular power icon
  left Auth-Gate sidebar
  neon circular SCAN button
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  AUTHENTICATION OF K1 GENESIS OWNER REQUIRED
  K1 COMPROMISED WALLET ADDRESS
  K1 input
  LINK DEVICE
  PASSKEY + ENTER below LINK DEVICE, if implemented
  AUTH-GATE explanatory copy
  STANDALONE OPERATION
  gold CAUTION block
  THANK YOU / BUILT BY EMP / @hope_ology

Locked/pre-auth screen must NOT show:

  recovery/deploy form
  deployer key field
  K1 compromised private key field
  K2 field
  K3 field
  chain selector
  funding controls
  deploy button
  2FA/protection panel
  deploy progress
  thank-you workflow controls
  Recovery / Protection / Admin / Status tabs as the public landing shell
  Made by Surf
  SurfAI
  surf-badge
  plaza-badge
  generic Surf scaffold

Do NOT re-add:

  sg-hero
  sg-main--locked
  sg-main--unlocked
  centered-hero experiment

Those were unwanted and must stay gone.

============================================================
2. REQUIRED UNLOCKED DASHBOARD
============================================================

After Auth-Gate unlock, the main dashboard must show the completed gated workspace.

The unlocked workspace must include these sections or tabs:

  Recovery
  Protection
  Admin
  Status

These sections may be tabs, cards, or panels, but they must be behind Auth-Gate.

They must not dominate the locked landing screen.

============================================================
3. AUTH-GATE REQUIREMENTS
============================================================

Auth-Gate must work as the gate before dashboard unlock.

Required behavior:

  K1 is entered before SCAN / LINK DEVICE / PASSKEY.
  K1 binds to the session.
  SCRUB clears the session and sensitive fields.
  SCAN = same-device Auth-Gate path.
  LINK DEVICE = same Auth-Gate ownership sweep through USB-linked device.
  PASSKEY verifies a K1-bound passkey.
  3 failed device attempts darken/disable SCAN + LINK only.
  PASSKEY and human fallback remain available after device attempts fail.
  Successful Auth-Gate unlock auto-fills K1 into the Recovery dashboard.
  Successful Auth-Gate generates or exposes a K1-bound passkey for later use.
  Human/admin passkey route can unlock only for the bound K1.

Do not expose exact hidden ownership-marker recipe in public copy.

Do not add QR flow.

Do not add operator proof flow.

============================================================
4. RECOVERY DASHBOARD REQUIREMENTS
============================================================

After unlock, Recovery must show and wire:

  K1 auto-filled from Auth-Gate
  deployer burner key field
  compromised K1 key field
  K2 public address field only
  K3 public address field only
  chain selector with chain names only
  funding/gas estimate control
  deploy/sign/broadcast flow
  progress/status area
  result/tx feedback
  SCRUB cleanup behavior

Critical security boundaries:

  Deployer burner key is browser/session-only.
  Compromised K1 key is browser/session-only.
  K2 private key is never entered.
  K3 private key is never entered.
  Backend never receives private keys.
  Backend never receives seed phrases.
  Backend receives signedTx only for broadcast/relay.
  K3 is immutable forced destination.
  No overrideDestination.
  No overrideDest.
  No k2OverrideDest.
  Thank-you address is separate from K3.
  Chain dropdown shows chain names only, never RPC URLs.
  RPC URLs are backend-env only.

Required user-facing progress labels exactly:

  Funding check
  Preparing gate
  Locking gate in
  Verifying protection
  Complete

Do not use user-facing wording:

  revoke
  bot
  sweeper
  Flashbots
  smoke test
  atomic bundle
  operator
  deployment bundle

============================================================
5. PROTECTION / 2FA REQUIREMENTS
============================================================

After unlock, Protection / 2FA must be visible and wired if it exists in source.

It must be a proactive/separate section, not mixed into the compromised recovery key flow.

Protection / 2FA must not require:

  K1 compromised private key
  K2 private key
  K3 private key
  seed phrase

It must not expose:

  revoke flow
  sweeper/bot flow
  operator flow
  public RPC URLs

If the section is not fully production-backed, label it honestly as limited/local/reference behavior, not production-ready.

============================================================
6. ADMIN REQUIREMENTS
============================================================

After unlock or through the black-circle/admin path, Admin must stay simple.

Admin flow must be:

  admin key + K1 address -> generate K1-bound passkey

Admin must NOT become:

  relay control panel
  operator dashboard
  queue dashboard
  revoke dashboard
  Flashbots dashboard
  veil/operator proof screen
  backend key custody interface

No private keys in Admin except the admin key used to generate a K1-bound passkey.

Generated passkey must be bound to one K1 only.

============================================================
7. STATUS REQUIREMENTS
============================================================

Status must show safe runtime/dashboard status only.

Allowed:

  chain names
  backend route availability
  artifact availability
  funding estimate status
  passkey/Auth-Gate status
  build/runtime status
  safe diagnostic messages

Forbidden:

  private keys
  seed phrases
  RPC URLs
  backend env values
  internal secrets
  operator secrets
  hidden ownership-marker recipe

============================================================
8. BACKEND ROUTES THAT MUST BE WIRED
============================================================

The frontend must call existing backend routes where appropriate.

Required route surface:

  backend/routes/chains.js
  backend/routes/funding.js
  backend/routes/rpc.js
  backend/routes/deploy.js
  backend/routes/passkeys.js
  backend/routes/admin-passkey.js
  backend/routes/artifact.js
  backend/routes/anti-abuse.js
  backend/routes/thank-you.js
  backend/routes/trace.js
  backend/routes/runtime.js

Frontend should use backend routes for:

  /api/chains
  /api/funding/:chain
  /api/rpc/:chain
  /api/deploy/:chain
  /api/passkeys/register
  /api/passkeys/verify
  /api/admin-passkey/generate
  /api/artifact/securegate
  /api/anti-abuse/event
  /api/thank-you/config
  /api/thank-you/send
  /api/trace/:kind
  /api/runtime, if present

Do not add forbidden routes:

  /api/recovery/execute
  /api/credentials
  /api/revoke
  /api/queue
  /api/authorize
  /api/execute
  /api/sweep

============================================================
9. IMPLEMENTATION RULE
============================================================

Do not return another plan.

Do one of two things:

A. If the unlocked dashboard is already fully wired:
   Return proof.

B. If anything is missing:
   Patch the smallest necessary source files, then return proof.

Likely allowed frontend files:

  frontend/src/App.tsx
  frontend/src/lib/*
  frontend/src/components/*
  frontend/src/index.css only if necessary for existing layout bugs

Likely allowed backend files only if a route is actually missing or broken:

  backend/routes/*
  backend/lib/*
  backend/config/*

Do NOT touch unless absolutely necessary:

  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  test/
  ABI
  Foundry artifacts
  K1/K2/K3 security model
  signedTx-only backend boundary

If contracts/out/test change, explain exactly why. Otherwise revert them.

============================================================
10. REQUIRED SCREENSHOT PROOF
============================================================

Return TWO screenshots.

Screenshot 1 — LOCKED:

Must show the DAPINK locked baseline:

  Auth-Gate sidebar
  neon SCAN
  K1 input
  LINK DEVICE
  PASSKEY + ENTER if implemented
  STANDALONE OPERATION
  CAUTION block
  SCRUB
  yellow power icon
  THANK YOU / BUILT BY EMP / @hope_ology
  no recovery form
  no dashboard tabs as landing
  no Surf branding

Screenshot 2 — UNLOCKED:

Must show the dashboard after Auth-Gate/passkey/human-route unlock.

It must visibly show:

  Recovery
  Protection
  Admin
  Status
  K1 auto-filled from Auth-Gate
  deployer burner key field
  compromised K1 key field
  K2 public address field only
  K3 public address field only
  chain selector with chain names only
  funding/gas section
  deploy/sign/broadcast area
  progress/status area
  thank-you section if included in completed dashboard

Important:
Do not fake unlock by hardcoding dashboardUnlocked = true.
Use an existing legitimate local/dev path:
  - passkey verify
  - admin-generated K1-bound passkey
  - human-route path if already implemented

If you cannot produce the unlocked screenshot, return:

  FAIL: unlocked dashboard screenshot not produced.

Do not mark complete.

============================================================
11. REQUIRED COMMAND PROOF
============================================================

Run with Node 24 wrapper.

A. Node version:

  bash scripts/with-node24.sh node -v

Expected:
  v24.x

B. Baseline design lock still intact:

  grep -RInE "sg-hero|sg-main--locked|sg-main--unlocked|DAPINK PRE-AUTH HERO|centered landing canvas|centered-hero" frontend/src/App.tsx frontend/src/index.css SECUREGATE-BUILD-CODE-HANDOFF.md || true

Expected:
  no hits

C. No forbidden branding:

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

Expected:
  no hits

D. Required DAPINK labels:

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

E. Front-back wiring verifier:

  bash scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs

Expected:
  verify-front-back-wiring: 20 passed, 0 failed

F. Recovery UI verifier:

  bash scripts/with-node24.sh node scripts/verify-recovery-flow-ui.cjs

Expected:
  verify-recovery-flow-ui: 7 passed, 0 failed

G. Funding/gas verifier:

  bash scripts/with-node24.sh node scripts/verify-funding-gas.cjs

Expected:
  verify-funding-gas: 7 passed, 0 failed

H. Auth-Gate verifier set:

  bash scripts/with-node24.sh node scripts/verify-authgate-session.cjs
  bash scripts/with-node24.sh node scripts/verify-authgate-sweep.cjs
  bash scripts/with-node24.sh node scripts/verify-authgate-attempt-limits.cjs
  bash scripts/with-node24.sh node scripts/verify-authgate-passkey.cjs

Expected:
  all pass

I. Admin/passkey verifier:

  bash scripts/with-node24.sh node scripts/verify-admin-passkey.cjs

Expected:
  pass

J. 2FA/protection verifier:

  bash scripts/with-node24.sh node scripts/verify-2fa-no-limits.cjs

Expected:
  pass

K. Thank-you verifier:

  bash scripts/with-node24.sh node scripts/verify-thank-you-envelope.cjs

Expected:
  pass

L. Design fidelity verifier:

  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs

Expected:
  verify-design-fidelity: 29 passed, 0 failed

M. Frontend build:

  cd frontend
  ../scripts/with-node24.sh npm run type-check
  ../scripts/with-node24.sh npm run build
  cd ..

Expected:
  both pass

N. Backend checks:

  cd backend
  ../scripts/with-node24.sh npm run selftest
  ../scripts/with-node24.sh npm run drift:scan
  ../scripts/with-node24.sh npm run verify:artifact
  cd ..

Expected:
  all pass

O. Contract/artifact checks:

  bash scripts/with-node24.sh forge build --via-ir
  bash scripts/with-node24.sh forge test -vvv
  bash scripts/with-node24.sh node scripts/verify-abi-canonical.cjs

Expected:
  all pass

P. Frontend route-call proof:

  grep -RInE "api\\('chains'\\)|api\\('thank-you/config'\\)|api\\('anti-abuse/event'\\)|api\\(`funding/|api\\(`rpc/|api\\(`deploy/|api\\('passkeys/register'\\)|api\\('passkeys/verify'\\)|api\\('admin-passkey/generate'\\)|api\\('artifact/securegate'\\)" frontend/src

Expected:
  hits proving frontend calls backend routes

Q. Backend route existence proof:

  ls backend/routes

Must include:
  chains.js
  funding.js
  rpc.js
  deploy.js
  passkeys.js
  admin-passkey.js
  artifact.js
  anti-abuse.js
  thank-you.js
  trace.js
  runtime.js

R. Forbidden drift scan:

  grep -RInE "K2_PRIVATE_KEY|K3_PRIVATE_KEY|DEPLOYER_PRIVATE_KEY|seed phrase|overrideDestination|overrideDest|k2OverrideDest|/api/recovery/execute|/api/credentials|/api/revoke|/api/queue|/api/authorize|/api/execute|/api/sweep|Flashbots|sweeper bot|SMOKE TEST|DEPLOYMENT BUNDLE" frontend/src backend contracts scripts || true

Expected:
  no active implementation hits

S. Backend/contracts untouched proof:

  git diff -- backend contracts out test

Expected:
  empty unless specifically justified

T. Frontend/source diff:

  git diff -- frontend/src/App.tsx frontend/src/index.css frontend/src/lib frontend/src/components

Expected:
  only minimal wiring fixes if any were needed

============================================================
12. PACKAGE RULE IF SOURCE CHANGED
============================================================

If no source changed, keep the ae82 baseline source hash.

If any source changed, create a new clean source ZIP.

Name it:

  securegate-eip777g-wired-dashboard-final.zip

It must contain:

  .node-version
  .nvmrc
  .npmrc
  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  frontend/index.html
  frontend/src/App.tsx
  frontend/src/index.css
  frontend/src/lib/*
  frontend/src/components/*
  backend/*
  scripts/with-node24.sh
  scripts/verify-zip-contents.cjs
  scripts/verify-design-fidelity.cjs

It must exclude:

  uploads/
  outputs/
  cache/
  node_modules/
  .git/
  restored-original*/
  _stitch_zip/

Run:

  sha256sum securegate-eip777g-wired-dashboard-final.zip
  bash scripts/with-node24.sh node scripts/verify-zip-contents.cjs securegate-eip777g-wired-dashboard-final.zip

Then extract and verify the ZIP:

  rm -rf /tmp/securegate-wired-check
  mkdir -p /tmp/securegate-wired-check
  unzip -q securegate-eip777g-wired-dashboard-final.zip -d /tmp/securegate-wired-check
  cd /tmp/securegate-wired-check

  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs
  bash scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs
  bash scripts/with-node24.sh node scripts/verify-recovery-flow-ui.cjs
  bash scripts/with-node24.sh node scripts/verify-funding-gas.cjs

Create:

  securegate-eip777g-wired-dashboard-final.zip.sha256
  securegate-eip777g-wired-dashboard-final.zip.b64.txt

Verify Base64 round trip:

  awk '!/^#/' securegate-eip777g-wired-dashboard-final.zip.b64.txt | base64 -d > /tmp/securegate-eip777g-wired-dashboard-final.decoded.zip
  sha256sum /tmp/securegate-eip777g-wired-dashboard-final.decoded.zip
  cmp securegate-eip777g-wired-dashboard-final.zip /tmp/securegate-eip777g-wired-dashboard-final.decoded.zip

============================================================
13. AUTO-FAIL CONDITIONS
============================================================

Return FAIL immediately if any are true:

  only locked screenshot is provided
  unlocked screenshot is missing
  response is only a plan
  no command output is provided
  design baseline is changed again
  sg-hero returns
  sg-main--locked returns
  sg-main--unlocked returns
  Made by Surf returns
  SurfAI returns
  surf-badge returns
  Recovery / Protection / Admin / Status appear as locked landing shell
  unlocked dashboard does not show recovery workspace
  K1 does not auto-fill after unlock
  K2 private-key field exists
  K3 private-key field exists
  backend receives private key or seed phrase
  public frontend exposes RPC URLs
  K3 override is accepted
  thank-you address is treated as K3
  forbidden routes are added
  backend/contracts/out/test changed without explanation
  source ZIP contains uploads/, outputs/, cache/, node_modules/, or .git/
  old source hash is claimed after source edits
  production-ready is claimed

============================================================
14. FINAL RESPONSE FORMAT
============================================================

Return exactly:

A. Verdict

  PASS or FAIL

B. Locked Baseline

  locked screenshot attached: yes/no
  DAPINK visual match: yes/no
  sg-hero/locked-main experiment absent: yes/no
  no Surf branding: yes/no

C. Unlocked Dashboard

  unlocked screenshot attached: yes/no
  Recovery visible: yes/no
  Protection visible: yes/no
  Admin visible: yes/no
  Status visible: yes/no
  K1 auto-filled: yes/no
  K2 public address only: yes/no
  K3 public address only: yes/no
  chain names only: yes/no
  funding/gas wired: yes/no
  deploy/sign/broadcast area wired: yes/no
  thank-you section present/wired: yes/no

D. Wiring Proof

  verify-front-back-wiring:
  verify-recovery-flow-ui:
  verify-funding-gas:
  verify-authgate-session:
  verify-authgate-sweep:
  verify-authgate-attempt-limits:
  verify-authgate-passkey:
  verify-admin-passkey:
  verify-2fa-no-limits:
  verify-thank-you-envelope:

E. Build Proof

  node version:
  frontend type-check:
  frontend build:
  backend selftest:
  backend drift scan:
  backend artifact verify:
  forge build:
  forge test:
  ABI canonical:

F. Source/Route Proof

  frontend backend-route grep:
  backend routes list:
  forbidden drift grep:
  backend/contracts/out/test diff:
  frontend/source diff:

G. Packaging, If Source Changed

  source changed: yes/no
  source ZIP filename:
  source ZIP sha256:
  verify-zip-contents:
  extracted ZIP wiring verifiers:
  Base64 decode/cmp:

H. Final Statement

  The locked DAPINK baseline is preserved.
  The full Recovery / Protection / Admin / Status dashboard is present only after Auth-Gate unlock.
  The unlocked dashboard is wired to the backend route surface.
  Backend/contracts/K1-K2-K3 logic were not changed.
  Backend receives signedTx only and never receives private keys or seeds.

Final line must be exactly:

No production-ready claim.
```

---

## Short Version If They Ignore Long Prompts

```txt
Do not give me another locked screenshot. The locked DAPINK baseline is accepted. Now prove or complete the unlocked dashboard behind Auth-Gate. I need two screenshots: locked DAPINK and unlocked dashboard. The unlocked screenshot must show Recovery / Protection / Admin / Status, K1 auto-filled, K2 public address only, K3 public address only, chain names only, funding/gas, deploy/sign/broadcast area, progress labels, and thank-you section. Run verify-front-back-wiring, verify-recovery-flow-ui, verify-funding-gas, Auth-Gate/passkey/admin/2FA/thank-you verifiers, frontend build, backend checks, forge checks, route grep, forbidden drift grep, and backend/contracts diff. Do not restyle DAPINK. Do not reintroduce sg-hero. Do not expose RPC URLs/private keys. No production-ready claim.
```

## What You Should Accept

Accept only when they provide:

```txt
locked screenshot
unlocked screenshot
verify-front-back-wiring: 20/20
verify-recovery-flow-ui: 7/7
verify-funding-gas: 7/7
Auth-Gate/passkey/admin/2FA/thank-you verifier passes
frontend build pass
backend checks pass
backend/contracts untouched proof
no forbidden branding/drift proof
new source ZIP/hash if source changed
```

## What You Should Reject

Reject if they provide only:

```txt
Restore complete
design-fidelity 29/29
locked DAPINK screenshot
frontend build OK
```

That proves the shell. It does **not** prove the completed dashboard behind Auth-Gate.

**Bottom line.** The next step is not more visual restore. It is **unlocked wired-dashboard proof**.

No production-ready claim.