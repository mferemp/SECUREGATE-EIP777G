# SecureGate - Final Master Prompt To Stop The Remaining Packaging Failure

## TL;DR

You were clear. The builder fixed the **new DAPINK source ZIP**, but still failed the **final handoff packaging** by leaving old artifacts/docs and not including the actual new handoff ZIP/Base64. This prompt blocks that exact failure.

Paste this exactly.

---

## Master Prompt

```txt
SECUREGATE / EIP-777G — FINAL HANDOFF CLEANUP + DAPINK SOURCE LOCK

This is a final packaging and proof task.

The DAPINK-fixed source candidate already exists and was verified:

  securegate-eip777g-dapink-final.zip
  SHA256: c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4

Do NOT regress from that.

The previous failure was:

- New DAPINK source ZIP existed and passed.
- But the final package still included old stale artifacts:
  - securegate-eip777g-final.zip.b64.txt
  - securegate-eip777g-final.zip.sha256
  - securegate-eip777g-handoff.zip.b64.txt
  - securegate-eip777g-handoff.zip.sha256
- Root docs still referenced old stale hashes:
  - 198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3
  - be5073e2054744349d70efa888e47bde3d76f850c80ff4b7bb761d7350ffce85
- Only securegate-eip777g-dapink-handoff.zip.sha256 was present.
- The actual new handoff ZIP / Base64 carrier was missing.
- No live screenshot proof was provided.

That must not happen again.

============================================================
0. FINAL OUTCOME
============================================================

Produce a clean final handoff package where the only current source/handoff artifacts are:

  securegate-eip777g-dapink-final.zip
  securegate-eip777g-dapink-final.zip.sha256
  securegate-eip777g-dapink-final.zip.b64.txt
  securegate-eip777g-dapink-handoff.zip
  securegate-eip777g-dapink-handoff.zip.sha256
  securegate-eip777g-dapink-handoff.zip.b64.txt

If direct ZIP upload is not possible, Base64 carriers are acceptable, but they must decode to the exact ZIP hashes.

The final package must not rely on a workspace wrapper.

A workspace wrapper is not source.
A Vercel URL is not proof.
A .sha256 file without the actual ZIP or Base64 carrier is not proof.
Markdown claims are not proof.

============================================================
1. ACCEPTED DAPINK SOURCE HASH
============================================================

The accepted DAPINK-fixed source candidate is:

  securegate-eip777g-dapink-final.zip
  SHA256: c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4

If you change any source file after this point, you must create a new DAPINK source ZIP and report the new SHA256.

If you do not change source files, keep this exact source hash.

Do not claim the old source hash is current:

  198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3

That old source is stale for DAPINK. It contained Made by Surf / surf-badge / plaza-badge and lacked the DAPINK design verifier.

============================================================
2. DELETE OR EXCLUDE STALE ARTIFACTS
============================================================

The final package must NOT include these stale files:

  securegate-eip777g-final.zip
  securegate-eip777g-final.zip.sha256
  securegate-eip777g-final.zip.b64.txt
  securegate-eip777g-handoff.zip
  securegate-eip777g-handoff.zip.sha256
  securegate-eip777g-handoff.zip.b64.txt

The final package must NOT present these old hashes as current:

  198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3
  be5073e2054744349d70efa888e47bde3d76f850c80ff4b7bb761d7350ffce85

If historical references are absolutely necessary, they must be under a clearly labeled DEPRECATED / OLD ARTIFACTS section and must not be in README front-door instructions.

Preferred rule:
Do not include them at all.

============================================================
3. UPDATE FRONT-DOOR DOCS
============================================================

Update these files:

  HANDOFF.md
  README-HANDOFF.md
  GIT-DIFF-CONFIRMATION.md
  SECUREGATE-EIP777G-FINAL-HANDOFF.md
  SECUREGATE-BUILD-CODE-HANDOFF.md

They must identify the current DAPINK source as:

  securegate-eip777g-dapink-final.zip
  c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4

They must identify the current DAPINK handoff as:

  securegate-eip777g-dapink-handoff.zip
  <new actual handoff SHA256>

They must not instruct a fresh builder to use:

  securegate-eip777g-final.zip
  securegate-eip777g-handoff.zip
  198f0637...
  be5073...

Run this proof:

  grep -RInE "198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3|be5073e2054744349d70efa888e47bde3d76f850c80ff4b7bb761d7350ffce85|securegate-eip777g-final.zip|securegate-eip777g-handoff.zip" HANDOFF.md README-HANDOFF.md GIT-DIFF-CONFIRMATION.md SECUREGATE-EIP777G-FINAL-HANDOFF.md SECUREGATE-BUILD-CODE-HANDOFF.md || true

Expected:
No current/front-door references. If any hits remain, they must be clearly labeled DEPRECATED and must not be instructions.

============================================================
4. VERIFY DAPINK SOURCE ZIP BY EXTRACTION
============================================================

Do not verify only the active root.

Extract the actual source ZIP and run checks inside the extracted directory.

Run:

  rm -rf /tmp/securegate-dapink-source-check
  mkdir -p /tmp/securegate-dapink-source-check

  awk '!/^#/' securegate-eip777g-dapink-final.zip.b64.txt | base64 -d > /tmp/securegate-eip777g-dapink-final.decoded.zip

  sha256sum securegate-eip777g-dapink-final.zip
  sha256sum /tmp/securegate-eip777g-dapink-final.decoded.zip
  cmp securegate-eip777g-dapink-final.zip /tmp/securegate-eip777g-dapink-final.decoded.zip

  unzip -q securegate-eip777g-dapink-final.zip -d /tmp/securegate-dapink-source-check
  cd /tmp/securegate-dapink-source-check

  cat .node-version
  cat .nvmrc
  cat .npmrc

  node scripts/verify-zip-contents.cjs ../securegate-eip777g-dapink-final.zip
  node scripts/verify-design-fidelity.cjs

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

Expected:

  source SHA256 = c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4
  decoded Base64 SHA256 = c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4
  cmp exits 0
  .node-version = 24
  .nvmrc = 24
  .npmrc contains engine-strict=true
  verify-zip-contents passes
  verify-design-fidelity: 29 passed, 0 failed
  no forbidden Surf branding hits
  required DAPINK labels present

============================================================
5. CREATE THE NEW HANDOFF ZIP
============================================================

Create the actual handoff ZIP:

  securegate-eip777g-dapink-handoff.zip

It must contain:

  README-HANDOFF.md
  HANDOFF.md
  SECUREGATE-BUILD-CODE-HANDOFF.md
  SECUREGATE-EIP777G-FINAL-HANDOFF.md
  GIT-DIFF-CONFIRMATION.md
  securegate-eip777g-dapink-final.zip
  securegate-eip777g-dapink-final.zip.sha256
  securegate-eip777g-dapink-final.zip.b64.txt

Optional:
  proofs/
  live-screenshot.png or live-screenshot.jpg

It must NOT contain:

  uploads/
  outputs/
  cache/
  node_modules/
  .git/
  restored-original*/
  _stitch_zip/
  securegate-eip777g-final.zip
  securegate-eip777g-final.zip.sha256
  securegate-eip777g-final.zip.b64.txt
  securegate-eip777g-handoff.zip
  securegate-eip777g-handoff.zip.sha256
  securegate-eip777g-handoff.zip.b64.txt

Then create:

  securegate-eip777g-dapink-handoff.zip.sha256
  securegate-eip777g-dapink-handoff.zip.b64.txt

============================================================
6. VERIFY HANDOFF ZIP BY EXTRACTION
============================================================

Do not stop at creating the handoff ZIP.

Extract it and verify the contained source ZIP again.

Run:

  sha256sum securegate-eip777g-dapink-handoff.zip
  unzip -t securegate-eip777g-dapink-handoff.zip
  unzip -l securegate-eip777g-dapink-handoff.zip

  awk '!/^#/' securegate-eip777g-dapink-handoff.zip.b64.txt | base64 -d > /tmp/securegate-eip777g-dapink-handoff.decoded.zip
  sha256sum /tmp/securegate-eip777g-dapink-handoff.decoded.zip
  cmp securegate-eip777g-dapink-handoff.zip /tmp/securegate-eip777g-dapink-handoff.decoded.zip

  rm -rf /tmp/securegate-dapink-handoff-check
  mkdir -p /tmp/securegate-dapink-handoff-check
  unzip -q securegate-eip777g-dapink-handoff.zip -d /tmp/securegate-dapink-handoff-check
  cd /tmp/securegate-dapink-handoff-check

  sha256sum securegate-eip777g-dapink-final.zip
  cat securegate-eip777g-dapink-final.zip.sha256

  rm -rf source-check
  mkdir source-check
  unzip -q securegate-eip777g-dapink-final.zip -d source-check
  cd source-check

  node scripts/verify-zip-contents.cjs ../securegate-eip777g-dapink-final.zip
  node scripts/verify-design-fidelity.cjs

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

Expected:
The handoff ZIP must contain the new DAPINK source ZIP and that contained source ZIP must pass the same DAPINK checks.

============================================================
7. ACTIVE BUILD PROOF
============================================================

From the active repo root, run:

  bash scripts/with-node24.sh node -v

  cd frontend
  ../scripts/with-node24.sh npm run type-check
  ../scripts/with-node24.sh npm run build
  cd ..

  cd backend
  ../scripts/with-node24.sh npm run selftest
  ../scripts/with-node24.sh npm run drift:scan
  ../scripts/with-node24.sh npm run verify:artifact
  cd ..

  bash scripts/with-node24.sh forge build --via-ir
  bash scripts/with-node24.sh forge test -vvv
  bash scripts/with-node24.sh node scripts/verify-abi-canonical.cjs
  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs

Expected:
All exit 0.

============================================================
8. BACKEND / CONTRACT UNTOUCHED PROOF
============================================================

This task is packaging and frontend/design finalization only.

Run:

  git diff -- backend contracts out test

Expected:
No diff.

If there is any diff, explain why it was necessary. Otherwise revert it.

Run:

  git diff -- frontend/index.html frontend/src/App.tsx frontend/src/index.css frontend/src/components frontend/src/lib scripts/verify-design-fidelity.cjs HANDOFF.md README-HANDOFF.md GIT-DIFF-CONFIRMATION.md SECUREGATE-EIP777G-FINAL-HANDOFF.md SECUREGATE-BUILD-CODE-HANDOFF.md

Expected:
Only DAPINK/frontend/doc/hash/handoff cleanup changes.

============================================================
9. LIVE SCREENSHOT PROOF
============================================================

A Vercel URL alone is not proof.

Provide:

  Vercel URL:
  deployed commit hash:
  root directory:
  framework preset:
  build command:
  output directory:
  live screenshot file:

The screenshot must visibly show:

  SECUREGATE / EIP-777G
  neon circular SCAN
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  K1 COMPROMISED WALLET ADDRESS
  LINK DEVICE
  PASSKEY
  STANDALONE OPERATION
  gold caution block
  pink SCRUB button
  yellow power icon
  THANK YOU
  BUILT BY EMP
  @hope_ology

The screenshot must NOT show:

  Made by Surf
  SurfAI
  surf-badge
  plaza-badge
  generic Surf scaffold
  Recovery / Protection / Admin / Status as the first visible landing shell

If screenshot proof cannot be produced, say exactly:

  BLOCKED: live screenshot proof not produced.

Do not mark complete.

============================================================
10. FINAL RESPONSE FORMAT
============================================================

Return exactly:

A. Verdict

  PASS or FAIL

B. Current Source ZIP

  filename:
  sha256:
  size:
  entries:
  Base64 decoded sha256:
  cmp result:
  verify-zip-contents result:
  verify-design-fidelity result:

C. Source Extraction Proof

  dotfiles:
  no-branding grep:
  DAPINK label grep:

D. Current Handoff ZIP

  filename:
  sha256:
  size:
  entries:
  Base64 decoded sha256:
  cmp result:
  unzip -t result:
  contained source ZIP sha256:

E. Handoff Extraction Proof

  contained source verify-zip-contents:
  contained source verify-design-fidelity:
  contained source no-branding grep:
  contained source DAPINK label grep:

F. Stale Artifact Removal Proof

  old artifact files present: yes/no
  old hashes in front-door docs: yes/no
  grep output:

G. Build Proof

  node version:
  frontend type-check:
  frontend build:
  backend selftest:
  backend drift scan:
  backend artifact verify:
  forge build:
  forge test:
  ABI canonical:
  design verifier:

H. Diff Proof

  backend/contracts/out/test diff:
  frontend/docs/handoff diff:

I. Live Deployment Proof

  Vercel URL:
  commit:
  build settings:
  screenshot attached: yes/no
  visual match: yes/no

J. Final Statement

  The DAPINK-fixed source is securegate-eip777g-dapink-final.zip.
  The old 198f0637... source is not being claimed as the DAPINK source.
  The old be5073... handoff is not being claimed as the DAPINK handoff.
  The new handoff bundle contains the new DAPINK source ZIP.
  Backend/contracts/K1-K2-K3 logic were not changed.

Final line must be exactly:

No production-ready claim.

============================================================
11. AUTO-FAIL CONDITIONS
============================================================

Return FAIL immediately if any of these happen:

- securegate-eip777g-dapink-handoff.zip is missing
- securegate-eip777g-dapink-handoff.zip.b64.txt is missing
- only securegate-eip777g-dapink-handoff.zip.sha256 is provided
- handoff ZIP does not contain securegate-eip777g-dapink-final.zip
- handoff ZIP contains old securegate-eip777g-final.zip
- handoff ZIP contains old securegate-eip777g-handoff.zip
- final package includes old source/handoff artifacts as current files
- front-door docs point to 198f0637... as current source
- front-door docs point to be5073... as current handoff
- extracted source ZIP contains Made by Surf
- extracted source ZIP contains surf-badge
- extracted source ZIP contains plaza-badge
- extracted source ZIP lacks scripts/verify-design-fidelity.cjs
- extracted source ZIP fails verify-design-fidelity
- extracted source ZIP fails verify-zip-contents
- source ZIP contains uploads/
- source ZIP contains outputs/
- source ZIP contains cache/
- source ZIP contains node_modules/
- source ZIP contains .git/
- source ZIP lacks .node-version / .nvmrc / .npmrc
- live Vercel URL is provided without screenshot
- screenshot shows generic Surf scaffold
- screenshot shows Recovery / Protection / Admin / Status as landing
- final response says production-ready

No production-ready claim.
```

---

## Short Paste Version

```txt
Final cleanup only. The DAPINK source candidate c4d0877b931aa07487b1ff9d9587a03d4e95a03bb00f7fc6b8466045790923d4 passed, but the handoff package failed because the actual securegate-eip777g-dapink-handoff.zip / .b64.txt was missing, old 198f/be5073 artifacts remained, docs still pointed to old hashes, and no live screenshot was provided. Create and include the actual new DAPINK handoff ZIP + Base64 carrier, remove old source/handoff artifacts, update all front-door docs to the DAPINK names/hashes, extract and verify both the source ZIP and handoff ZIP, prove no Made by Surf/surf-badge/plaza-badge, prove DAPINK labels exist, provide build/backend/contract proof, and attach live screenshot. A .sha256 without the ZIP/Base64 is not proof. A workspace wrapper is not source. A Vercel URL is not proof. No production-ready claim.
```

## Acceptance Rule

Do not accept the next response unless it includes:

```txt
securegate-eip777g-dapink-final.zip.b64.txt
securegate-eip777g-dapink-final.zip.sha256
securegate-eip777g-dapink-handoff.zip.b64.txt
securegate-eip777g-dapink-handoff.zip.sha256
proof that both Base64 files decode to matching ZIP hashes
proof that the handoff ZIP contains the DAPINK source ZIP
proof that extracted contained source passes verify-design-fidelity
proof old 198f/be5073 artifacts/docs are not current
live screenshot proof
```

**Bottom line.** This prompt blocks the latest failure: **passing source ZIP, but missing/dirty final handoff.**

No production-ready claim.