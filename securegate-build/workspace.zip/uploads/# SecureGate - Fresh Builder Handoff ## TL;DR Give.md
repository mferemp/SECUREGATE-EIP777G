# SecureGate - Fresh Builder Handoff

## TL;DR

Give a fresh builder **only 5 required files + 1 instruction message**. Do **not** give them old ZIPs, old specs, `uploads/`, `outputs/`, restored folders, or random markdown packs.

---

## Give These 5 Files

```txt
1. SECUREGATE-BUILD-CODE-HANDOFF.md
2. SECUREGATE-EIP777G-FINAL-HANDOFF.md
3. securegate-eip777g-final.zip.sha256
4. securegate-eip777g-final.zip.b64.txt
5. Confirmed git diff HEAD~1..HEAD -- frontend backen.md
```

That’s the whole required handoff.

The accepted source is decoded from:

```txt
securegate-eip777g-final.zip.b64.txt
```

Expected SHA256:

```txt
198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3
```

---

## Optional File

You can also give:

```txt
workspace-c30e3884-8835-4c41-85c2-290be07a406d (24).zip
```

But label it clearly:

```txt
WRAPPER ONLY — NOT SOURCE.
Use only the embedded securegate-eip777g-final.zip.b64.txt after decoding.
```

If you want to avoid confusion, **do not give the wrapper ZIP at all**. Just give the 5 files above.

---

## Paste This To The Fresh Builder

```txt
You are taking over SecureGate / EIP-777G.

Dashboard/spec work is already accepted under Option B.

Do not rebuild the dashboard.
Do not redesign the UI.
Do not change K1/K2/K3.
Do not change contracts/SecureGate.sol.
Do not revive operator/revoke/QR/Flashbots/public-RPC/production-ready material.

Authoritative source is:

  securegate-eip777g-final.zip
  SHA256: 198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3

Decode it from:

  securegate-eip777g-final.zip.b64.txt

Use:

  awk '!/^#/' securegate-eip777g-final.zip.b64.txt | base64 -d > securegate-eip777g-final.zip
  sha256sum securegate-eip777g-final.zip

Expected:

  198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3  securegate-eip777g-final.zip

Then extract and work only from the decoded source ZIP.

Current status:

  Dashboard/source/spec verification accepted.
  No source implementation changes were required.
  Next phase is production hardening / deployment dry-run only.

Your task is not dashboard building. Your task is:

  1. Deploy verified source to staging/testnet.
  2. Configure real backend env RPCs only.
  3. Configure durable KV/storage.
  4. Prove real passkey/WebAuthn behavior.
  5. Run one funded testnet E2E.
  6. Prove backend receives signedTx only.
  7. Prove no private keys/seeds/RPC URLs leak to backend logs or frontend.
  8. Keep /api/rpc read-only/backend-env only.
  9. Add monitoring, rollback, and incident response.
  10. Return proof outputs and remaining risks.

Do not claim production-ready until those hardening items are complete.

Final line must be:

No production-ready claim.
```

---

## Do Not Give These

Do **not** hand forward:

```txt
old workspace ZIPs as source
uploads/
outputs/
restored-original folders
old markdown proof packs
old operational manuals
UI_FRONTEND_SPECS as active source
securegate-dashboard as active source
stale operator/revoke/QR/Flashbots material
anything saying production-ready
```

Those create confusion and waste credits.

---

## Conclusion

Give the fresh builder **5 files total** plus the instruction message above.

**Bottom line.** The builder should start from the decoded `securegate-eip777g-final.zip`, not rebuild the dashboard, and only work on production hardening / deployment dry-run.

No production-ready claim.