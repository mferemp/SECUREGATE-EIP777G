# SecureGate EIP-777G Frontend UI Specifications

**Status:** Production-Ready | **Theme:** Dark Terminal Aesthetic | **Framework:** Vanilla JS + HTML/CSS

---

## Design System

### Color Palette (CSS Custom Properties)

| Token | Hex Value | Usage | Notes |
|-------|-----------|-------|-------|
| `--bg-primary` | `#0a0a0f` | Main background (near-black) | No warm tint, neutral |
| `--bg-secondary` | `#11131a` | Card/panel backgrounds | Slightly elevated |
| `--bg-tertiary` | `#181c26` | Tertiary surface (hover states) | Additional depth |
| `--bg-card` | `#141821` | Floating cards, modals | Distinct from backgrounds |
| `--border-primary` | `#2a2f3a` | Main borders | Low contrast, refined |
| `--border-secondary` | `#3a3f4a` | Secondary borders | Slightly more contrast |
| `--text-primary` | `#e8eaf0` | Primary text | Off-white, readable |
| `--text-secondary` | `#9aa3b2` | Secondary text labels | Reduced emphasis |
| `--text-muted` | `#6b7280` | Muted text, placeholders | Very low contrast |
| `--accent-primary` | `#00d4aa` | Teal/cyan — primary CTA | High energy, calls action |
| `--accent-primary-dim` | `#00d4aa22` | Teal with 13% opacity | Backgrounds, hover states |
| `--accent-secondary` | `#7c4dff` | Purple — secondary accent | Alternative emphasis |
| `--accent-secondary-dim` | `#7c4dff22` | Purple with 13% opacity | Subtle backgrounds |
| `--danger` | `#ff4757` | Error, revoke, destructive | High visibility |
| `--danger-dim` | `#ff475722` | Error background | Soft alert backgrounds |
| `--warning` | `#ffa502` | Warning states | Scanning, in-progress |
| `--warning-dim` | `#ffa50222` | Warning background | Cautionary surfaces |
| `--success` | `#2ed573` | Success, verified, complete | Positive confirmation |
| `--success-dim` | `#2ed57322` | Success background | Celebratory surfaces |

### Typography

| Element | Font Family | Size | Weight | Usage |
|---------|-------------|------|--------|-------|
| **Body** | `'Inter', -apple-system, BlinkMacSystemFont, sans-serif` | 13–16px | 500–600 | Readable UI text |
| **Monospace** | `'JetBrains Mono', ui-monospace, SFMono-Regular, monospace` | 12–14px | 400–700 | Code, addresses, values |
| **Headlines** | `'Inter'` | 24–40px | 700–900 | Page titles, section heads |

### Spacing & Radius

| Token | Value | Usage |
|-------|-------|-------|
| `--radius-sm` | 6px | Buttons, small inputs, corners |
| `--radius-md` | 10px | Cards, modals, medium components |
| `--radius-lg` | 14px | Large modals, overlays |
| Base spacing scale | 4px, 8px, 16px, 24px, 32px | Padding, margins, gaps |

### Shadows

| Token | CSS | Usage |
|-------|-----|-------|
| `--shadow-sm` | `0 1px 3px rgba(0,0,0,0.3)` | Subtle depth |
| `--shadow-md` | `0 4px 12px rgba(0,0,0,0.4)` | Medium depth |
| `--shadow-lg` | `0 8px 24px rgba(0,0,0,0.5)` | Modal/overlay shadow |

### Transitions

| Token | Duration | Easing |
|-------|----------|--------|
| `--transition-fast` | 150ms | ease |
| `--transition-normal` | 250ms | ease |

---

## Layout Structure

### Fixed Topbar (Section 1–2)

**Dimensions:** 42px height, full width, `z-index: 900`

**Sections:**
1. **Identity (Left)**
   - Logo: "SECUREGATE" (gradient teal→magenta)
   - Subtitle: "EIP-777G" (gold, 8px, spaced)
   - Two distinct lines, never collapse

2. **Controls (Right)**
   - SCRUB button (solid magenta, white text, 900 weight)
   - POWER button (gold ring, circular, 28px)
   - Network selector (dropdown with custom arrow)

### Sidebar (Section 3)

**Dimensions:** 264px fixed width, full height minus topbar

**Content:**
- SCAN button (primary action, top priority)
- Navigation menu items
- Status indicators
- Scrollbar (thin, custom color)

**Scrollbar Styling:**
- Track: `--bg-secondary`
- Thumb: `--border-secondary`
- Thumb hover: `--text-muted`

### Main Content Area (Section 4)

**Dimensions:** Flexible, fills remaining space

**Structure:**
- Tab navigation (pill-style buttons)
- Panel grid layout (1fr + 380px sidebar on large screens, stacks on mobile)
- Responsive breakpoints:
  - `@media (max-width: 1100px)`: Single column
  - `@media (max-width: 768px)`: Mobile adjustments (tighter padding, smaller text)
  - `@media (max-width: 600px)`: Extra-compact (full-width inputs)

---

## Component Styles

### Buttons

**Base Button (`.btn`)**
- Padding: 10px 18px (0.625rem 1.125rem)
- Height: 44px (iOS minimum touch target)
- Border-radius: `--radius-sm`
- Font: 14px / 600 weight (0.85rem, 600)
- Transition: all 150ms

**Variants:**
- `.btn-primary`: Teal background, dark text
  - Hover: +10% brightness, -1px translateY
- `.btn-secondary`: Tertiary bg, border, gray text
  - Hover: elevated bg, teal border
- `.btn-danger`: Red background
  - Hover: +10% brightness
- `.btn-ghost`: Transparent, minimal
  - Hover: tertiary bg

**States:**
- `:disabled`: 50% opacity, not-allowed cursor
- `:focus-visible`: 2px teal outline, 2px offset

### Input Fields

**Standard Input (`.secure-input`)**
- Padding: 12px 48px 12px 16px (right space for toggle)
- Font-family: monospace
- Background: `--bg-primary`
- Border: 1px `--border-primary`
- Border-radius: `--radius-sm`
- Transition: border-color + box-shadow 150ms

**Focus State:**
- Border-color: teal
- Box-shadow: 0 0 0 3px `--accent-primary-dim`

**Toggle Button (`.input-toggle`)**
- 36x36px, positioned right
- Icon: 18x18px
- Eye icon toggles on interaction

**Placeholder:** `--text-muted`

### Modal Overlay

**Structure:**
- Fixed, full viewport, z-index 9999
- Backdrop: rgba(10,10,15,0.92)
- Animation: 300ms scale(0.94) → scale(1)

**Modal Content:**
- Max-width: 360px
- Background: `--bg-card`
- Border: 1px `--border-primary`
- Border-radius: `--radius-lg`
- Shadow: `--shadow-lg`

**Close Button:**
- 32x32px, top-right
- Background: `--bg-secondary`
- Hover: danger-dim background, danger border

### Auth Overlay

**Structure:**
- Similar to modal, but `z-index: 10000`
- Blur backdrop (20px)

**Container:**
- Max-width: 420px
- Padding: 40px 32px
- Animation: 400ms auth-enter

**Header:**
- Title: 40px / 700 weight, gradient text
- Subtitle: 15px, secondary color

### Info Cards (`.info-card`)

- Background: `--bg-card`
- Border: 1px `--border-primary`
- Border-radius: `--radius-md`
- Padding: 20px
- Header: 13px / 600 weight, bottom border

### Tab Navigation

**Tab Nav (`.tab-nav`)**
- Pill-style container
- Background: `--bg-secondary`
- Border: 1px `--border-primary`
- Border-radius: `--radius-md`
- Padding: 4px (internal gap)
- Gap: 4px between tabs

**Tab Buttons (`.tab-btn`)**
- Flex: 1
- Padding: 10px 16px
- Border-radius: `--radius-sm`
- Font: 13px / 600

**States:**
- Default: secondary text
- Hover: primary text, tertiary bg
- Active: teal text, teal-dim background

### Status Cards

**Grid:** `repeat(auto-fit, minmax(280px, 1fr))`

**Card Content:**
- Title: 12px / 700, uppercase, muted
- Items: flex rows, space-between
- Value: monospace, 13px

**Status Values:**
- `.status-value.yes`: success (green)
- `.status-value.no`: danger (red)
- `.status-value.warn`: warning (orange)

### Progress Modal

**Steps Display:**
- Flex column, gap 12px
- Each step: bordered card, 14px padding

**Step States:**
- Default: primary border
- `.active`: teal border, teal-dim bg
- `.completed`: success border, success-dim bg
- `.failed`: danger border, danger-dim bg

**Step Number:**
- 32x32px circle
- Indicator: emoji (✓, ✗) on completion/failure

### Toasts/Notifications

**Container:**
- Fixed bottom-right, z-index 9999
- Flex column, gap 8px
- Pointer-events: none (container), auto (toasts)

**Toast (`.toast`)**
- Padding: 16px 20px
- Min-width: 280px, max-width: 420px
- Animation: 300ms slideInRight
- Border-left: 4px (color varies)

**Toast Variants:**
- `.success`: green left border
- `.error`: red left border
- `.warning`: orange left border
- `.info`: teal left border

---

## Critical Security Elements

### Operator Proof Flow (Lines ~710–740)

**HTML:**
```html
<input type="password" id="operator-proof-input" class="secure-input" />
<button id="submit-revoke-bundle" class="btn btn-primary">Revoke</button>
```

**Rules:**
- Never remove the `operator-proof-input` field
- JavaScript reads from input field (never hardcoded)
- Backend validates `X-Operator-Proof` header
- Environment variable: `OPERATOR_VEIL_PHRASE` (never committed)
- 403 Forbidden if proof fails

### Private Key Handling

- **Never send keys to server** — sign locally, send only signature
- K1, K2, K3 are user-input only (never auto-filled)
- Deployer key created on-device from k1-key input
- Keys cleared from memory after use

### Immutable K3 Destination

- K3 locked immutable in contract after deploy
- Frontend shows K3 input + on-chain verification pre-revoke
- No address substitution or routing changes allowed

### Device Sweep Verification

- 4 scan steps must display:
  1. First-visit check
  2. Device marker validation
  3. On-chain verification
  4. Session confirmation
- Minimum 800ms delay before showing result
- All artifacts found must display before proceeding

### CSP Security Headers (vercel.json)

```json
{
  "headers": [
    {
      "key": "Content-Security-Policy",
      "value": "default-src 'self'; script-src 'self' 'unsafe-inline'; form-action 'none'; connect-src 'self' https://eth-mainnet.infura.io https://eth-rpc.example.com"
    }
  ]
}
```

**Rules:**
- `script-src`: 'self' and 'unsafe-inline' only
- `form-action`: MUST be 'none' (prevents form POST attacks)
- `connect-src`: whitelisted RPC providers only
- No third-party JS, fonts, or tracking

---

## Animation & Interaction

### Entrance Animations

| Element | Animation | Duration | Easing |
|---------|-----------|----------|--------|
| Auth modal | scale(0.96) → scale(1) | 400ms | ease-out |
| QR modal | scale(0.94) → scale(1) | 300ms | ease-out |
| Tab panel | translateY(4px) → 0 | 200ms | ease |
| Toast | translateX(100%) → 0 | 300ms | ease-out |

### Hover States

- Buttons: translateY(-1px)
- Cards: subtle lift on `:hover`
- Inputs: border-color glow on `:focus-visible`

### Loading States

**Spinner:**
- SVG rotation: 360° infinite (1s linear)
- Applied to buttons with `.spinner` class

**Pulse Animation:**
- Used for status indicators
- 1s cycle: opacity 1 → 0.4 → 1

---

## Responsive Behavior

### Large Screens (>1100px)

- Panel grid: `1fr 380px` (content + sidebar)
- Full width layout
- All components at full scale

### Medium Screens (768–1100px)

- Panel grid: single column (stacks vertically)
- Padding reduced to 16px
- Tab buttons slightly smaller

### Mobile (<768px)

- Padding: 16px
- Input row: single column
- Deploy actions: flex-direction column, full width buttons
- Modal max-width: 100%
- Font sizes: -10%

### Extra Small (<600px)

- Input row: `1fr` (single column)
- Status grid: single column
- Auth container: reduced padding (16px)
- Font sizes: further reduced

---

## Custom Scrollbar

```css
::-webkit-scrollbar { width: 8px; height: 8px; }
::-webkit-scrollbar-track { background: var(--bg-secondary); }
::-webkit-scrollbar-thumb { background: var(--border-secondary); border-radius: 4px; }
::-webkit-scrollbar-thumb:hover { background: var(--text-muted); }
```

Firefox: `scrollbar-width: thin; scrollbar-color: var(--faint) transparent;`

---

## Text Selection & Focus

**Selection:**
- Background: `--accent-primary-dim`
- Color: `--text-primary`

**Focus Outline:**
- 2px solid teal
- 2px offset

**Tap Highlight:** Disabled globally via `-webkit-tap-highlight-color: transparent`

---

## File Structure

| File | Purpose |
|------|---------|
| `index.html` | Main HTML structure, auth overlay, dashboard layout |
| `css/style.css` | All design tokens, component styles, animations |
| `js/app.js` | Frontend logic (auth, data fetch, UI updates) |
| `vendor/ethers.umd.min.js` | ethers.js v5 (self-hosted, CSP-safe) |
| `vendor/tailwindcss.min.js` | TailwindCSS (optional, used in /live) |

---

## Notes

- **No external CDNs:** All assets self-hosted (fonts, JS libraries)
- **CSP-compliant:** No inline scripts except in `<style>` tag
- **Mobile-first:** Design starts at 320px, enhances upward
- **Accessible:** Focus states, color contrast, ARIA labels
- **Performance:** Minimal paint, efficient transitions, cached DOM queries

---

**Last Updated:** July 9, 2026  
**Next Review:** Before production deployment  
**Maintenance:** See HANDOFF.md for critical updates
