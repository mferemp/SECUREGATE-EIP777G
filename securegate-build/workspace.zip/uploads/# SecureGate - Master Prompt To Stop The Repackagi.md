# SecureGate - Master Prompt To Stop The Repackaging Failure

## TL;DR

You were clear. The recurring failure is now specific: **builders patch the outer workspace, then leave the embedded source ZIP stale**. This master prompt makes that impossible by requiring **source ZIP ↔ decoded source ↔ handoff ZIP ↔ live deploy** to all prove the same DAPINK-fixed code.

Paste this exactly.

---

## Master Prompt

```txt
SECUREGATE / EIP-777G — FINAL SOURCE-PACKAGING + DAPINK DESIGN LOCK

This task is NOT complete until the corrected DAPINK frontend exists inside the authoritative source ZIP, not only in the outer workspace.

The previous failure pattern was:

- patched frontend existed in the outer workspace root
- design-fidelity verifier passed in the outer root
- BUT embedded securegate-eip777g-final.zip was still stale
- old embedded source still had Made by Surf / surf-badge / plaza-badge
- old embedded source lacked scripts/verify-design-fidelity.cjs
- old embedded source lacked required DAPINK labels
- handoff bundle still pointed to the old stale source

That must not happen again.

============================================================
0. FINAL OUTCOME
============================================================

Produce a NEW clean source artifact and NEW handoff bundle where:

1. The active repo root contains the DAPINK-fixed SecureGate frontend.
2. The packaged source ZIP contains the SAME DAPINK-fixed SecureGate frontend.
3. Decoding the ZIP from Base64 reproduces the SAME source ZIP hash.
4. The consolidated handoff bundle contains the SAME new source ZIP.
5. The live deployment matches DAPINK visually.
6. No claim depends on markdown text alone.
7. No production-ready claim is made.

If the outer workspace is fixed but the source ZIP is stale, the task fails.

If the source ZIP is fixed but the handoff bundle contains an old ZIP, the task fails.

If the Vercel page is live but visually wrong, the task fails.

============================================================
1. SOURCE HASH RULE
============================================================

The old source ZIP hash:

  198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3

was accepted for the previous source state, but it is NOT allowed to be claimed as the DAPINK-fixed source if frontend/design files changed.

A DAPINK frontend fix changes source content, so the final DAPINK source ZIP MUST have a NEW SHA256.

Do not say:

  securegate-eip777g-final.zip 198f0637... is DAPINK-fixed

unless you can prove, by extracting that exact ZIP, that it contains:
- scripts/verify-design-fidelity.cjs
- DAPINK labels in frontend/src/App.tsx
- no Made by Surf / surf-badge / plaza-badge in frontend/index.html

If the hash is still 198f0637..., assume it is stale until proven otherwise.

============================================================
2. ACTIVE SOURCE ROOT REQUIREMENTS
============================================================

The clean active source root must include:

  .node-version
  .nvmrc
  .npmrc
  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  frontend/index.html
  frontend/src/App.tsx
  frontend/src/index.css
  backend/package.json
  frontend/package.json
  scripts/with-node24.sh
  scripts/verify-zip-contents.cjs
  scripts/verify-design-fidelity.cjs

Dotfile contents:

  .node-version = 24
  .nvmrc = 24
  .npmrc contains engine-strict=true

The clean source ZIP must NOT contain:

  uploads/
  outputs/
  restored-original*/
  _stitch_zip/
  node_modules/
  .git/
  cache/
  workspace wrapper files
  old proof-only attachment dumps

A workspace wrapper ZIP is not source.

============================================================
3. DAPINK VISUAL SOURCE OF TRUTH
============================================================

The public landing UI must match the supplied DAPINK / SecureGate neon dashboard.

Required public labels/visual concepts:

  SECUREGATE
  EIP-777G
  neon circular SCAN
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  AUTHENTICATION OF K1 GENESIS OWNER REQUIRED
  K1 COMPROMISED WALLET ADDRESS
  LINK DEVICE
  PASSKEY
  ENTER
  AUTH-GATE
  STANDALONE OPERATION
  BY USING SECUREGATE YOU ACKNOWLEDGE YOU ALREADY MADE A POOR LIFE CHOICE
  SCRUB
  yellow circular power icon
  THANK YOU
  BUILT BY EMP
  @hope_ology

Forbidden public UI branding/shell:

  Made by Surf
  SurfAI
  Surf AI
  surf-badge
  plaza-badge
  asksurf.ai badge
  Surf Plaza
  generic Surf scaffold
  generic SaaS dashboard shell
  Recovery / Protection / Admin / Status as dominant first visible landing screen

Recovery / Protection / Admin / Status may exist only behind the correct Auth-Gate unlock. They must not replace the DAPINK landing view.

============================================================
4. FILES YOU MAY CHANGE
============================================================

This is a frontend visual restoration plus packaging task.

Allowed likely changes:

  frontend/src/App.tsx
  frontend/src/index.css
  frontend/index.html
  frontend/src/components/*
  frontend/src/lib/*
  scripts/verify-design-fidelity.cjs
  handoff packaging scripts/docs only if needed

Do NOT change unless absolutely necessary:

  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  backend/routes/deploy.js
  backend/routes/rpc.js
  backend route safety
  K1/K2/K3 model
  ABI
  Foundry artifacts
  signedTx-only backend boundary

If backend/contracts/out/test/scripts unrelated to design changed, explain exactly why. Otherwise revert them.

============================================================
5. SECURITY MODEL MUST REMAIN UNCHANGED
============================================================

Preserve:

- K1 initiates/proves ownership/session binding
- K2 signs scoped EIP-712 typed-data intent only
- K3 is immutable forced destination
- backend receives signedTx / signed intent only
- backend never receives private keys
- backend never receives seed phrases
- RPC URLs are backend-env only
- frontend never exposes RPC URLs
- K2 public address only
- K3 public address only
- thank-you address remains separate from K3
- SCRUB clears local/session state
- PASSKEY path remains available
- LINK DEVICE remains Auth-Gate path
- chain names only in frontend, no public RPC strings

Do not introduce:

  K2 private-key field
  K3 private-key field
  backend K1/K2/K3 private-key custody
  seed phrase input
  overrideDestination
  overrideDest
  k2OverrideDest
  /api/recovery/execute
  /api/credentials
  /api/revoke
  /api/queue
  /api/authorize
  /api/execute
  /api/sweep
  Revoke UI
  QR flow
  operator proof UI
  Flashbots public wording
  sweeper/bot public wording
  smoke-test public wording
  production-ready claim

============================================================
6. DESIGN-FIDELITY VERIFIER REQUIRED
============================================================

Create or update:

  scripts/verify-design-fidelity.cjs

It must scan public frontend source only:

  frontend/src/App.tsx
  frontend/src/index.css
  frontend/index.html
  relevant frontend/src/components/*
  relevant frontend/src/lib/*

It must FAIL if public frontend contains:

  Made by Surf
  SurfAI
  Surf AI
  surf-badge
  plaza-badge
  asksurf.ai
  Surf Plaza
  generic Surf
  surf scaffold

It must FAIL if required DAPINK labels are missing:

  SECUREGATE
  EIP-777G
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  K1 COMPROMISED WALLET ADDRESS
  LINK DEVICE
  PASSKEY
  AUTH-GATE
  STANDALONE OPERATION
  BY USING SECUREGATE YOU ACKNOWLEDGE
  SCRUB
  BUILT BY EMP
  @hope_ology

It must FAIL if the tabbed workspace is the landing shell.

It must PASS only when:

  STANDALONE OPERATION appears before the tabbed workspace
  dashboardUnlocked or equivalent gate wraps Recovery / Protection / Admin / Status
  SCAN circle exists
  SCAN/LINK lock behavior remains honest
  no Surf branding appears in public frontend

Expected output:

  verify-design-fidelity: 29 passed, 0 failed

Important:
The verifier script itself may contain forbidden strings as test patterns. That is fine.
The no-branding grep must target public frontend files, not the verifier script.

============================================================
7. REQUIRED COMMAND PROOF — ACTIVE ROOT
============================================================

From the corrected repo root, run and return output:

A. Node/runtime:

  cat .node-version
  cat .nvmrc
  cat .npmrc
  bash scripts/with-node24.sh node -v

B. No public Surf branding:

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

Expected:
No hits.

C. Required DAPINK labels:

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

Expected:
Hits in public frontend source.

D. Design verifier:

  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs

Expected:

  verify-design-fidelity: 29 passed, 0 failed

E. Frontend:

  cd frontend
  ../scripts/with-node24.sh npm run type-check
  ../scripts/with-node24.sh npm run build
  cd ..

F. Backend:

  cd backend
  ../scripts/with-node24.sh npm run selftest
  ../scripts/with-node24.sh npm run drift:scan
  ../scripts/with-node24.sh npm run verify:artifact
  cd ..

G. Contract/artifact:

  bash scripts/with-node24.sh forge build --via-ir
  bash scripts/with-node24.sh forge test -vvv
  bash scripts/with-node24.sh node scripts/verify-abi-canonical.cjs

H. Backend/contracts untouched proof:

  git diff -- backend contracts out test

Expected:
No changes, unless explicitly justified.

I. Frontend/design diff:

  git diff -- frontend/index.html frontend/src/App.tsx frontend/src/index.css frontend/src/components frontend/src/lib scripts/verify-design-fidelity.cjs

Expected:
Only DAPINK visual restoration / verifier changes.

============================================================
8. CREATE NEW CLEAN SOURCE ZIP
============================================================

After active root passes, create a NEW clean source ZIP.

Name:

  securegate-eip777g-dapink-final.zip

Do NOT reuse the stale old source ZIP.

Before zipping, ensure excluded paths are absent from the staged source.

Example packaging rule:

  Exclude:
    .git/
    node_modules/
    uploads/
    outputs/
    restored-original*/
    _stitch_zip/
    cache/
    temporary proof dumps

The ZIP must include active-root dotfiles:

  .node-version
  .nvmrc
  .npmrc

Then run:

  sha256sum securegate-eip777g-dapink-final.zip
  bash scripts/with-node24.sh node scripts/verify-zip-contents.cjs securegate-eip777g-dapink-final.zip

Expected:

  [PASS] standard ZIP central directory parsed
  [PASS] all required active-root files present
  [PASS] no uploads/, outputs/, restored-original-*, _stitch_zip/, node_modules/, or .git paths
  [PASS] ZIP content gate satisfied

The new SHA256 must be reported.

============================================================
9. VERIFY THE ZIP BY EXTRACTION — THIS IS MANDATORY
============================================================

Do not trust the active root alone.

Extract the newly created source ZIP into a clean temp folder and verify the extracted contents.

Run:

  rm -rf /tmp/securegate-dapink-verify
  mkdir -p /tmp/securegate-dapink-verify
  unzip -q securegate-eip777g-dapink-final.zip -d /tmp/securegate-dapink-verify
  cd /tmp/securegate-dapink-verify

  cat .node-version
  cat .nvmrc
  cat .npmrc

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs
  bash scripts/with-node24.sh node scripts/verify-zip-contents.cjs ../securegate-eip777g-dapink-final.zip

Expected:
The extracted ZIP must prove the DAPINK fix exists inside the ZIP.

If the active root passes but the extracted ZIP fails, stop and report failure.

============================================================
10. CREATE BASE64 CARRIER AND VERIFY ROUND TRIP
============================================================

Create:

  securegate-eip777g-dapink-final.zip.sha256
  securegate-eip777g-dapink-final.zip.b64.txt

Then verify the Base64 carrier:

  awk '!/^#/' securegate-eip777g-dapink-final.zip.b64.txt | base64 -d > /tmp/securegate-eip777g-dapink-final.decoded.zip
  sha256sum /tmp/securegate-eip777g-dapink-final.decoded.zip
  sha256sum securegate-eip777g-dapink-final.zip
  cmp securegate-eip777g-dapink-final.zip /tmp/securegate-eip777g-dapink-final.decoded.zip

Expected:
The decoded ZIP hash must exactly match the source ZIP hash.

============================================================
11. CREATE NEW CONSOLIDATED HANDOFF BUNDLE
============================================================

Create a NEW handoff ZIP.

Name:

  securegate-eip777g-dapink-handoff.zip

It must contain:

  README-HANDOFF.md
  HANDOFF.md
  SECUREGATE-BUILD-CODE-HANDOFF.md
  SECUREGATE-EIP777G-FINAL-HANDOFF.md
  GIT-DIFF-CONFIRMATION.md
  securegate-eip777g-dapink-final.zip
  securegate-eip777g-dapink-final.zip.sha256
  securegate-eip777g-dapink-final.zip.b64.txt

Do not include stale:

  securegate-eip777g-final.zip with hash 198f0637...
  old securegate-eip777g-handoff.zip with hash be5073...
  uploads/
  outputs/
  workspace wrappers

Then run:

  sha256sum securegate-eip777g-dapink-handoff.zip
  unzip -t securegate-eip777g-dapink-handoff.zip
  unzip -l securegate-eip777g-dapink-handoff.zip

Expected:
The handoff ZIP must contain the NEW DAPINK source ZIP, not the stale old one.

============================================================
12. VERIFY HANDOFF BUNDLE BY EXTRACTION
============================================================

Extract the handoff bundle and verify the contained source ZIP again.

Run:

  rm -rf /tmp/securegate-dapink-handoff-verify
  mkdir -p /tmp/securegate-dapink-handoff-verify
  unzip -q securegate-eip777g-dapink-handoff.zip -d /tmp/securegate-dapink-handoff-verify
  cd /tmp/securegate-dapink-handoff-verify

  sha256sum securegate-eip777g-dapink-final.zip
  cat securegate-eip777g-dapink-final.zip.sha256

  rm -rf source-check
  mkdir source-check
  unzip -q securegate-eip777g-dapink-final.zip -d source-check
  cd source-check

  grep -RInE "Made by Surf|SurfAI|Surf AI|surf-badge|plaza-badge|asksurf.ai|Surf Plaza|generic Surf|surf scaffold" frontend/src frontend/index.html || true

  grep -RInE "SECUREGATE|EIP-777G|GENESIS OWNER AUTHENTICATION|DASHBOARD LOCKED|K1 COMPROMISED WALLET ADDRESS|LINK DEVICE|PASSKEY|AUTH-GATE|STANDALONE OPERATION|BY USING SECUREGATE YOU ACKNOWLEDGE|SCRUB|BUILT BY EMP|@hope_ology" frontend/src frontend/index.html

  bash scripts/with-node24.sh node scripts/verify-design-fidelity.cjs

Expected:
The handoff bundle must unpack to the same DAPINK-fixed source.

============================================================
13. LIVE DEPLOYMENT PROOF
============================================================

A Vercel URL alone is not proof.

Return:

1. Vercel URL
2. deployed commit hash
3. exact build settings:
   - root directory
   - framework preset
   - build command
   - output directory
4. screenshot of the live page

The screenshot must show:

  SECUREGATE / EIP-777G
  neon circular SCAN
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  K1 COMPROMISED WALLET ADDRESS
  LINK DEVICE
  PASSKEY
  STANDALONE OPERATION
  gold caution block
  pink SCRUB button
  yellow power icon
  THANK YOU
  BUILT BY EMP
  @hope_ology

The screenshot must NOT show:

  Made by Surf
  SurfAI
  surf-badge
  plaza-badge
  generic Surf scaffold
  Recovery / Protection / Admin / Status as the first visible landing shell

If screenshot proof is unavailable, say:

  BLOCKED: live screenshot proof not produced.

Do not mark complete.

============================================================
14. REQUIRED FINAL RESPONSE FORMAT
============================================================

Return exactly this structure:

A. Verdict

  PASS or FAIL.

B. Source ZIP

  filename:
  sha256:
  size:
  entries:
  verify-zip-contents output:

C. Extracted Source ZIP Proof

  no-branding grep output:
  required-label grep output:
  verify-design-fidelity output:

D. Base64 Round Trip

  decoded sha256:
  cmp result:

E. Handoff Bundle

  filename:
  sha256:
  size:
  entries:
  unzip -t result:
  contained source zip sha256:

F. Active Root Proof

  frontend type-check:
  frontend build:
  backend selftest:
  backend drift scan:
  backend artifact verify:
  forge build:
  forge test:
  ABI canonical verify:

G. Diff Proof

  frontend/design diff:
  backend/contracts/out/test diff:

H. Live Deployment Proof

  Vercel URL:
  commit:
  build settings:
  screenshot attached: yes/no
  visual match: yes/no

I. Final Statement

  The DAPINK screenshot was used as the visual source of truth.
  The corrected DAPINK frontend exists inside the active root, the source ZIP, the Base64-decoded ZIP, and the handoff bundle.
  The old stale 198f0637... source ZIP is not being claimed as the DAPINK-fixed source.
  Backend/contracts/K1-K2-K3 logic were not changed.

Final line must be exactly:

No production-ready claim.

============================================================
15. AUTO-FAIL CONDITIONS
============================================================

Immediately fail if any of these are true:

- source ZIP hash is still 198f0637... while claiming DAPINK is fixed
- handoff ZIP hash is still be5073... while claiming DAPINK is fixed
- extracted source ZIP lacks scripts/verify-design-fidelity.cjs
- extracted source ZIP frontend/index.html contains Made by Surf
- extracted source ZIP frontend/index.html contains surf-badge
- extracted source ZIP frontend/index.html contains plaza-badge
- extracted source ZIP App.tsx lacks STANDALONE OPERATION
- extracted source ZIP App.tsx lacks GENESIS OWNER AUTHENTICATION
- extracted source ZIP App.tsx lacks BUILT BY EMP
- source ZIP misses .node-version / .nvmrc / .npmrc
- source ZIP contains uploads/
- source ZIP contains outputs/
- source ZIP contains node_modules/
- source ZIP contains .git/
- Vercel URL is provided without screenshot
- screenshot shows generic Surf scaffold
- screenshot shows Recovery / Protection / Admin / Status as the public landing shell
- final response says production-ready

If any auto-fail condition occurs, stop and return FAIL with the exact failed check.

No production-ready claim.
```

---

## Short Version To Paste If They Ignore Long Prompts

```txt
Do not mark complete unless the DAPINK-fixed frontend is present in four places: active repo root, extracted source ZIP, Base64-decoded source ZIP, and extracted handoff bundle. The old 198f0637... source hash is stale if DAPINK files changed. Create a NEW clean source ZIP with a NEW SHA256, include .node-version/.nvmrc/.npmrc, exclude uploads/outputs/node_modules/.git, run verify-zip-contents and verify-design-fidelity on the EXTRACTED ZIP, prove no Made by Surf/surf-badge/plaza-badge in frontend/src + frontend/index.html, prove required DAPINK labels exist, prove frontend build passes, prove backend/contracts unchanged, and attach live screenshot matching DAPINK. Vercel URL alone is not proof. No production-ready claim.
```

## Acceptance Rule

Do **not** accept “done” unless they provide:

```txt
NEW source ZIP SHA256
NEW handoff ZIP SHA256
verify-zip-contents output from the extracted source ZIP
verify-design-fidelity output from the extracted source ZIP
Base64 decode/cmp proof
grep proof from extracted source ZIP
frontend build proof
backend/contracts untouched proof
live screenshot proof
```

**Bottom line.** This prompt blocks the exact failure: fixing the workspace while shipping a stale embedded source ZIP.

No production-ready claim.