# SecureGate / EIP-777G - Final Dashboard Prompt

## TL;DR

Use a prompt that **forces the builder to either prove the existing dashboard is already complete or make real source-code edits**. After the latest wrapper review, the key is: **the outer workspace ZIP is not source; decode the embedded `securegate-eip777g-final.zip`, verify hash `198f0637...f39a3`, then either Option A = implement missing source code, or Option B = prove no source edits are required.**

Paste this prompt.

---

## Paste-Ready Prompt

```txt
You are completing and verifying the SecureGate / EIP-777G dashboard to final spec.

This is not a planning task.
This is not a markdown-only report task.
This is not a new architecture task.
This is not a redesign task.

Your job is to work from the verified SecureGate source artifact and return either:

OPTION A — Implementation:
  You found missing dashboard behavior, edited actual source files, built the dashboard, and proved the changes with source diffs and raw command output.

OR

OPTION B — Verification:
  You proved the active dashboard already satisfies the final spec, made no source edits, and returned raw proof showing source hash, route safety, frontend/backend builds, verifier outputs, and clean git state.

If only markdown files change, the handoff is rejected unless you explicitly choose Option B and prove the active source already satisfies the final dashboard spec.

Final line must be exactly:

No production-ready claim.

================================================================
0. SOURCE ARTIFACT RULE
================================================================

The workspace ZIP is a delivery/proof wrapper only. It is not the active source if it fails the ZIP content gate.

Use only the decoded source artifact:

  securegate-eip777g-final.zip
  sha256: 198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3

If provided as Base64, decode:

  awk '!/^#/' securegate-eip777g-final.zip.b64.txt | base64 -d > securegate-eip777g-final.zip
  sha256sum securegate-eip777g-final.zip

Expected:

  198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3  securegate-eip777g-final.zip

Extract clean:

  rm -rf securegate-final
  mkdir securegate-final
  unzip securegate-eip777g-final.zip -d securegate-final
  cd securegate-final

Verify source ZIP gate:

  node scripts/verify-zip-contents.cjs ../securegate-eip777g-final.zip

Expected:

  [PASS] standard ZIP central directory parsed (204 entries)
  [PASS] all 70 required active-root files present
  [PASS] no uploads/, outputs/, restored-original-*, _stitch_zip/, node_modules/, or .git paths
  [PASS] ZIP content gate satisfied

Required active-root files include:

  .node-version = 24
  .nvmrc = 24
  .npmrc contains engine-strict=true
  frontend/package.json
  backend/package.json
  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  scripts/verify-zip-contents.cjs

If this source gate fails, stop and request the correct four files:

  SECUREGATE-BUILD-CODE-HANDOFF.md
  SECUREGATE-EIP777G-FINAL-HANDOFF.md
  securegate-eip777g-final.zip.sha256
  securegate-eip777g-final.zip.b64.txt

Do not work from:
  uploads/
  outputs/
  restored-original folders
  workspace wrapper ZIPs
  old markdown proof packs
  stale operational manuals

================================================================
1. SOURCE HIERARCHY
================================================================

Use this hierarchy:

  1. securegate-eip777g-final.zip = active source of truth
  2. SECUREGATE-EIP777G-FINAL-HANDOFF.md = proof/source verification truth
  3. SECUREGATE-BUILD-CODE-HANDOFF.md = code reference
  4. securegate-dashboard (19).md = corrected product behavior
  5. UI_FRONTEND_SPECS (4).md = visual shell/design baseline only
  6. owner corrections/final rules override all conflicts

Quarantine stale material:

  operator/revoke/QR/Flashbots/sweeper/smoke-test/public-RPC/production-ready sections are not active requirements.

================================================================
2. DASHBOARD COMPLETION TARGET
================================================================

The complete dashboard must include and prove:

  A. Auth-Gate sidebar
  B. SCAN same-device path
  C. LINK DEVICE same Auth-Gate sweep via linked device
  D. PASSKEY input + ENTER lane below LINK DEVICE
  E. K1-bound passkey generation/display after successful Auth-Gate
  F. Admin black-circle passkey generator inside CAUTION block
  G. Recovery panel unlocked only after Auth-Gate/passkey
  H. K1 auto-fill/session binding
  I. K2 public-address-only field
  J. K3 public-address-only field
  K. Chain selector with chain names only, no RPC URLs
  L. Funding/gas estimate action through backend route
  M. Deploy/protect action using signedTx-only backend route
  N. Separate 2FA/proactive protection section
  O. Separate thank-you envelope section
  P. Five canonical public progress labels only
  Q. No stale operator/revoke/QR/Flashbots/public-RPC drift

If any of this is missing, edit actual source files.
If all of it already exists, choose Option B and prove it.

Likely source files to inspect/edit:

  frontend/src/App.tsx
  frontend/src/index.css
  frontend/src/lib/uiLabels.ts
  frontend/src/lib/authGateSession.ts
  frontend/src/lib/authGateSweep.ts
  frontend/src/lib/passkey*.ts
  frontend/src/lib/securegate*.ts
  frontend/src/lib/thankYouEnvelope.ts
  frontend/src/lib/twoFactor*.ts
  backend/routes/deploy.js
  backend/routes/funding.js
  backend/routes/chains.js
  backend/routes/rpc.js
  backend/routes/thank-you.js
  backend/routes/anti-abuse.js
  backend/routes/admin-passkey.js
  backend/routes/passkeys.js
  backend/lib/*.js
  backend/scripts/*.cjs

Do not solve this by only creating:
  IMPLEMENTATION_COMPLETE.md
  DASHBOARD_IMPLEMENTATION_STATUS.md
  FINAL_VERIFICATION_REPORT.md
  any other markdown-only report

Markdown may be proof companion only.

================================================================
3. DESIGN FIDELITY REQUIREMENTS
================================================================

Do not redesign the product.

Preserve:

  dark terminal / near-black background
  teal + magenta accents
  SECUREGATE / EIP-777G topbar branding
  power/SCRUB control
  fixed Auth-Gate sidebar
  SCAN circle with animated ring
  GENESIS OWNER AUTHENTICATION label
  DASHBOARD LOCKED banner
  K1 COMPROMISED WALLET ADDRESS input
  LINK DEVICE button
  PASSKEY input + ENTER below LINK DEVICE
  CAUTION block
  admin black-circle button inside CAUTION block
  STANDALONE OPERATION info panel
  BUILT BY EMP / @hope_ology / 777G footer identity
  terminal/monospace brand feel

UI_FRONTEND_SPECS is visual guidance only. Do not copy stale operator/revoke/QR/public-RPC/production-ready sections.

================================================================
4. AUTH-GATE REQUIREMENTS
================================================================

Implement or prove in active source:

  K1 must be entered before SCAN, LINK DEVICE, or PASSKEY.
  Once SCAN or LINK starts, K1 binds to the session.
  K1 cannot silently change without SCRUB.
  SCRUB clears local/session state.
  SCAN performs same-device ownership signal check.
  LINK DEVICE performs the same Auth-Gate ownership check via linked device.
  Exact marker recipe stays hidden.
  After 3 failed SCAN/LINK attempts for the same K1, SCAN and LINK darken/disable.
  PASSKEY path remains open.
  Human fallback remains open.
  2FA is not blocked by Auth-Gate counters.

Public copy must stay abstract.

Allowed examples:

  Checking local ownership signals...
  Device checks are paused for this key. The PASSKEY path and human fallback remain open.
  Session cleared.

Do not reveal:
  marker recipes
  exact scan internals
  hidden breadcrumbs
  fingerprint details
  key material
  seed phrases
  private proof mechanics

================================================================
5. PASSKEY REQUIREMENTS
================================================================

PASSKEY lane must be visible directly below LINK DEVICE:

  PASSKEY [________________] [ENTER]

Implement or prove:

  Passkey is bound to one K1 address only.
  Passkey is not per-chain.
  K1 + passkey unlocks only if binding matches.
  Mismatch fails generically.
  UI does not reveal whether K1 or passkey was wrong.
  After successful Auth-Gate, generate/display a K1-bound passkey.
  Lost passkey requires re-running Auth-Gate or human fallback.

Required copy:

  Save this passkey. It is bound to this K1 only. If lost, you must re-run Auth-Gate.

================================================================
6. ADMIN BLACK-CIRCLE REQUIREMENTS
================================================================

The admin black-circle button must remain inside the CAUTION block.

Click opens a compact panel only.

Fields:

  Admin key
  K1 address
  Generate passkey

Output:

  Generated K1-bound passkey
  Copy button

Rules:

  Admin key + K1 creates a K1-bound passkey.
  This is for manual/human fallback only.
  Do not create a full admin dashboard.
  Do not add operator screens.
  Do not add queue screens.
  Do not add relay controls.
  Do not add revoke controls.
  Do not add veil pages.
  Do not add K2 signing.
  Do not add K3 override.

================================================================
7. RECOVERY DASHBOARD REQUIREMENTS
================================================================

Recovery unlocks only after:

  successful Auth-Gate, or
  valid K1-bound passkey

After unlock:

  K1 auto-fills from Auth-Gate.
  K1 remains session-bound unless SCRUB clears session.
  User may enter deployer burner key locally/session-only.
  User may enter compromised K1 key locally/session-only.
  K2 is public address only.
  K3 is public address only.
  Never ask for K2 private key.
  Never ask for K3 private key.
  K3 is immutable forced destination.
  Assets route only to K3.
  Non-K3 attempted destinations are captured/flagged internally only.
  Backend receives signedTx only.
  Backend never receives private keys.
  Backend never receives seed phrases.
  Backend never receives destination override keys.

Required visible fields/actions:

  K1 compromised address, auto-filled/session-bound
  Deployer burner key, local/session-only
  Compromised K1 key, local/session-only
  K2 public address
  K3 public address
  Chain selector
  Funding/gas estimate action
  Deploy/protect action

Chain selector:

  Show chain names only.
  Do not show RPC URLs.
  Do not expose browser process.env RPC values.
  RPC URLs are backend-env only.

================================================================
8. FUNDING / GAS / DEPLOY REQUIREMENTS
================================================================

Funding/gas estimation must go through backend routes only.

Allowed public labels:

  Calculate funding
  Estimate required gas

Deploy/broadcast rule:

  backend/routes/deploy.js receives signedTx only.

Reject/remove any code that allows:

  backend private-key custody
  backend K1 private-key custody
  backend deployer private-key custody
  server-side K2 signing
  user-supplied frontend RPC URLs
  returned public RPC URLs
  overrideDestination
  overrideDest
  k2OverrideDest
  signedTx: "0x00"
  txHash: "pending"
  fake verified:true
  all-zero placeholder signature accepted as valid

================================================================
9. PUBLIC PROGRESS LABELS
================================================================

Public progress labels must be exactly these five, in this order:

  Funding check
  Preparing gate
  Locking gate in
  Verifying protection
  Complete

No other public progress labels are allowed.

Do not expose public UI text containing:

  revoke
  bot
  sweeper
  Flashbots
  relay
  smoke test
  atomic bundle
  deployment bundle
  queue
  authorizeIntent
  executeIntent
  artifact internals
  raw tx mechanics
  public RPC URL

Technical terms may appear only in:
  internal code
  verifier assertions
  docs warnings
  tests
  blocklists
  hidden developer diagnostics

They must not appear as public user-facing copy.

================================================================
10. 2FA / PROACTIVE SECTION
================================================================

Add or prove separate 2FA / proactive protection.

Rules:

  2FA is separate from compromised-wallet recovery.
  2FA has no compromised K1 key.
  2FA has no recovery limits.
  2FA is not blocked by Auth-Gate/download/recovery/passkey counters.
  2FA is for proactive protection before compromise.
  No revoke/bot/sweeper language.
  No recovery cleanup sweep wording.

Do not implement 2FA as a confusing toggle inside compromised-wallet recovery.

================================================================
11. THANK-YOU ENVELOPE
================================================================

Add or prove optional thank-you envelope UI.

Rules:

  Thank-you address is separate from K3.
  Thank-you address is not K3.
  Thank-you address cannot affect routing.
  Thank-you address is not a deploy parameter.
  Thank-you address is not proof logic.
  Thank-you flow is optional.
  It may include a note box, copyable address, send/copy action, and @hope_ology reference.

Do not let thank-you fields modify:
  recovery destination
  K3
  deploy parameters
  proof logic

================================================================
12. BACKEND ROUTE RULES
================================================================

Classify every backend/API route.

Run:

  find backend api -maxdepth 3 -type f | sort

Allowed route classes:

  signedTx-only deploy/broadcast
  backend-env read-only RPC bridge
  funding/gas estimate
  chain metadata
  anti-abuse/rate-limit
  K1-bound passkey fallback
  thank-you envelope
  artifact delivery
  static health/status
  opaque trace diagnostics

/api/rpc is allowed only if it is a backend-env read-only bridge:

  no user-supplied RPC URLs
  no returned RPC URLs
  no private keys
  no seed phrases
  no override destination keys
  read/estimate methods only
  no raw tx broadcast
  broadcast remains backend/routes/deploy.js signedTx-only

Forbidden active routes:

  /api/recovery/execute
  /api/credentials
  /api/revoke
  /api/queue
  /api/authorize
  /api/execute
  /api/sweep, unless proven internal-only and not public UI behavior
  /api/recovery, unless proven human/passkey fallback only and not execute/revoke/sweep behavior

If uncertain, remove the route or prove it is not used by the frontend.

================================================================
13. CANONICAL CONTRACT / ARTIFACT
================================================================

Do not rename the architecture.

Canonical contract:

  contracts/SecureGate.sol

Canonical ABI/artifact:

  out/SecureGate.sol/SecureGate.json

Required ABI signatures:

  DOMAIN_SEPARATOR()
  GATE_CHAIN_ID()
  K1()
  K2()
  K3()
  authorizeIntent(bytes32,bytes)
  computeAuthorizationDigest(bytes32)
  computeIntentHash(uint8,address,uint256,uint256,bytes32,uint256)
  executeIntent(bytes32)
  intents(bytes32)
  queueERC1155(address,uint256,uint256,bytes32,uint256)
  queueERC20(address,uint256,bytes32,uint256)
  queueERC721(address,uint256,bytes32,uint256)
  recordAttemptedDestination(address)
  suspectDestination(address)
  usedNonces(bytes32)

Forbidden old ABI names:

  queueIntent
  forwardERC20
  computeEIP712Digest
  domainSeparator

Do not call this SafeGate.
Do not convert this into another architecture.
EIP-712 is only the K2 typed-data signing mechanism.
Do not call SecureGate an EIP-712 project, architecture, or invention.

================================================================
14. FORBIDDEN DRIFT TO PURGE
================================================================

Purge forbidden active behavior/copy:

  queueIntent
  forwardERC20
  computeEIP712Digest
  domainSeparator
  operator-proof-input
  submitRevokeBundle
  submit-revoke-bundle
  getOperatorProof
  /api/recovery/execute
  /api/credentials
  /api/revoke
  /api/queue
  /api/authorize
  /api/execute
  OPERATOR_VEIL_PHRASE
  X-Operator-Proof
  visible Revoke flow
  QR flow
  Flashbots public wording
  smoke test public wording
  sweeper bot public wording
  DEPLOYMENT BUNDLE public wording
  public frontend RPC URLs
  browser process.env RPC
  server-side K2 signing
  backend K1 private-key custody
  backend deployer private-key custody
  K2 private-key field
  K3 private-key field
  overrideDestination acceptance
  overrideDest acceptance
  k2OverrideDest acceptance
  signedTx: "0x00"
  txHash: "pending"
  fake verified:true
  all-zero 65-byte placeholder signature accepted as valid
  EIP-712 project/architecture/invention naming drift
  production-ready claim

Allowed appearances only in:

  verifier rejection assertions
  blocklists
  docs warnings
  tests proving absence
  historical quarantine notes
  import/function names that are internal-only and classified by verify-no-drift

No active/public UI behavior may contain those items.

================================================================
15. NODE 24 REQUIREMENT
================================================================

Node 24 only.

Required files:

  .node-version = 24
  .nvmrc = 24
  .npmrc contains engine-strict=true

Required package engines:

  backend/package.json engines.node = ">=24 <25"
  frontend/package.json engines.node = ">=24 <25"

Use:

  scripts/with-node24.sh

Do not downgrade to Node 20 or Node 22.

If a package command says “no package.json,” check directory. Expected:

  frontend/package.json
  backend/package.json

Do not assume a root package.json exists.

================================================================
16. REQUIRED BUILD COMMANDS
================================================================

From repo root:

  scripts/with-node24.sh node -v

Frontend:

  cd frontend
  ../scripts/with-node24.sh npm install
  ../scripts/with-node24.sh npm run type-check
  ../scripts/with-node24.sh npm run build
  cd ..

Backend:

  cd backend
  ../scripts/with-node24.sh npm install
  ../scripts/with-node24.sh npm run selftest
  ../scripts/with-node24.sh npm run drift:scan
  ../scripts/with-node24.sh npm run verify:artifact
  cd ..

Canonical artifact:

  scripts/with-node24.sh node scripts/verify-abi-canonical.cjs

Source ZIP gate:

  scripts/with-node24.sh node scripts/verify-zip-contents.cjs ../securegate-eip777g-final.zip

Foundry:

  scripts/with-node24.sh forge --version
  scripts/with-node24.sh forge build --via-ir
  scripts/with-node24.sh forge test -vvv

If Foundry is unavailable, do not fake it. State exactly:

  Foundry not available in this environment; forge build/test not reproduced here. Prior source artifact proof says forge build --via-ir passed and forge test -vvv passed 4/4. This run verified the precompiled ABI artifact statically only.

================================================================
17. REQUIRED VERIFIER BATTERY
================================================================

Run every available verifier that exists in the repo.

Core verifiers:

  scripts/with-node24.sh node scripts/verify-ui-baseline.cjs
  scripts/with-node24.sh node scripts/verify-no-drift.cjs
  scripts/with-node24.sh node scripts/verify-authgate-session.cjs
  scripts/with-node24.sh node scripts/verify-authgate-sweep.cjs
  scripts/with-node24.sh node scripts/verify-authgate-attempt-limits.cjs
  scripts/with-node24.sh node scripts/verify-authgate-passkey.cjs || scripts/with-node24.sh node backend/scripts/verify-passkey-lane.cjs
  scripts/with-node24.sh node scripts/verify-admin-passkey.cjs
  scripts/with-node24.sh node scripts/verify-2fa-no-limits.cjs
  scripts/with-node24.sh node scripts/verify-recovery-flow-ui.cjs
  scripts/with-node24.sh node scripts/verify-funding-gas.cjs
  scripts/with-node24.sh node scripts/verify-recovery-cleanup-sweep.cjs
  scripts/with-node24.sh node scripts/verify-blacklist-k3.cjs
  scripts/with-node24.sh node scripts/verify-k3-execution-sweep.cjs
  scripts/with-node24.sh node scripts/verify-k2-intent-builders.cjs
  scripts/with-node24.sh node scripts/verify-wallet-k2-flow.cjs
  scripts/with-node24.sh node scripts/verify-front-back-wiring.cjs
  scripts/with-node24.sh node scripts/verify-thank-you-envelope.cjs
  scripts/with-node24.sh node scripts/verify-contract-obfuscation-layers.cjs
  scripts/with-node24.sh node scripts/verify-obfuscation-ci.cjs
  scripts/with-node24.sh node scripts/verify-anti-abuse-downloads.cjs
  scripts/with-node24.sh node scripts/verify-placeholder-gates.cjs

If verify-k2-intent-builders.cjs fails because anvil is unavailable, do not call it a complete pass. State exactly:

  The anvil-backed K2 intent-builder verifier was not reproduced in this environment because anvil is unavailable.
  The wallet K2 flow fallback verifier passed and provides client-side K2 authorization coverage.
  Full anvil-backed K2 proof remains dependent on an environment with Foundry/anvil installed.

If obfuscation is skipped, state exactly:

  SKIPPED: no obfuscated build configured
  Contract/dashboard obfuscation is NOT complete.

================================================================
18. VISUAL ACCEPTANCE CHECKLIST
================================================================

Manually verify and report:

  Auth-Gate sidebar visible
  SCAN circle visible
  K1 input visible
  LINK DEVICE visible
  PASSKEY input + ENTER button visible below LINK DEVICE
  CAUTION block visible
  Admin black-circle inside CAUTION block
  Dashboard unlocks after Auth-Gate/passkey
  K1 auto-fills recovery panel
  K2 public address field visible
  K3 public address field visible
  Chain dropdown shows chain names only
  Funding/gas estimate action visible
  Public progress labels are exactly:
    Funding check
    Preparing gate
    Locking gate in
    Verifying protection
    Complete
  2FA/proactive section visible and separate
  Thank-you envelope visible and separate
  Footer identity preserved
  No forbidden public words visible

================================================================
19. SOURCE DIFF PROOF — MANDATORY
================================================================

Return raw git/source proof:

  git status --short
  git show --stat --oneline HEAD
  git show --name-status HEAD
  git diff HEAD~1..HEAD -- frontend backend scripts contracts test

If only markdown/report files changed, say:

  Only documentation/proof files changed. No dashboard source implementation changes were made.

If the dashboard source already satisfied the spec and no source changes were required, say:

  No source implementation changes were required because the active dashboard source already satisfied the final spec.

Then prove that with:
  file references
  visible UI checklist
  route listing/classification
  raw verifier outputs

================================================================
20. FINAL RESPONSE REQUIREMENTS
================================================================

Return:

  1. Branch
  2. Commit
  3. Source ZIP SHA256
  4. Option A or Option B
  5. Changed files
  6. What changed in each source file, or “no source edits required”
  7. Raw git diff/stat output
  8. Route listing from:
       find backend api -maxdepth 3 -type f | sort
  9. Route classification for every route
  10. Explicit absent forbidden routes
  11. Frontend type-check raw output
  12. Frontend build raw output
  13. Backend selftest raw output
  14. Backend drift scan raw output
  15. Backend artifact verification raw output
  16. ABI canonical verification raw output
  17. Forge build/test raw output or exact Foundry caveat
  18. Full verifier battery raw output
  19. Foundry/anvil status
  20. Obfuscation status
  21. Design fidelity checklist
  22. Remaining gaps, if any

Allowed status wording:

  Source/build verification passed in this environment.
  Ready for next review/deployment dry-run.
  Foundry/anvil limitations documented where applicable.

Do not include:
  production-ready
  deployment-ready
  all blockers resolved unless all source-diff and verifier requirements are actually satisfied
  summary counts without raw outputs

Final line must be exactly:

No production-ready claim.
```

---

## Why This Is The Right Prompt

This version gets you a complete dashboard because it blocks the two bad outcomes you kept getting:

1. **Markdown-only “implementation complete” reports.**  
   The prompt requires `git diff` over `frontend backend scripts contracts test`.

2. **Work from the wrong artifact.**  
   The prompt forces the builder to decode and verify the embedded source ZIP, not use the wrapper ZIP.

It also allows the correct final state after attachment 42:

```txt
Option B: no source edits required because the active dashboard already satisfied the spec.
```

That matters because the latest accepted proof indicates the dashboard may already be complete; the builder should not make unnecessary edits just to show activity.

---

## Acceptance Standard

Accept the builder’s response only if it includes one of these:

### Option A — actual implementation

```txt
Source code changed under frontend/backend/scripts/etc.
Dashboard builds.
Verifier battery passes.
Diff proves the missing behavior was implemented.
No production-ready claim.
```

### Option B — no source edits required

```txt
Clean active source verified.
No source edits required.
Dashboard requirements mapped to active files.
Route listing/classification included.
Frontend/backend/Foundry/verifier proof included.
No production-ready claim.
```

Reject if the response only says:

```txt
implementation complete
all tests pass
148+ checks passed
ready for deployment
created report
created implementation summary
```

without raw outputs and source-diff proof.

---

## Conclusion

The prompt above is the clean final version: it results in a complete dashboard by forcing either **real implementation** or **full proof that implementation was already complete**. It also keeps the source artifact, K1/K2/K3 model, route safety, UI fidelity, and no-production-claim boundary locked.

**Bottom line.** Use this prompt and judge the response by the source diff plus raw verifier output, not by summary language.

No production-ready claim.