# SecureGate - Master Prompt To Stop Design Drift

## TL;DR

You were clear. The specs were clear. The failure is that the builder treated **tests passing** as the same thing as **visual/design compliance**. This master prompt makes that impossible: **DAPINK image wins. If the live UI does not match the image, the job fails even if every verifier passes.**

Paste this exactly.

---

## Master Prompt

```txt
SECUREGATE / EIP-777G — FINAL DESIGN-LOCK RESTORE

The current GitHub/Vercel deployment is rejected.

Reason:
It does not match the supplied SecureGate dashboard design. It looks like a generic Surf/tabbed dashboard and includes wrong public branding/shell.

The specs were clear:
- securegate-dashboard (20).md = product/dashboard behavior
- UI_FRONTEND_SPECS (5).md = visual shell/design baseline, except its stale “production-ready” wording is quarantined
- DAPINK image = binding visual target

The DAPINK image is the visual source of truth.

If the live dashboard does not visually match DAPINK, the task is not complete, even if:
- frontend build passes
- backend tests pass
- verifier battery passes
- Vercel deploy succeeds
- source hash is correct

Tests passing is not design acceptance.

============================================================
0. NON-NEGOTIABLE OUTCOME
============================================================

Restore the public landing/dashboard UI to match DAPINK.

The first visible screen must look like DAPINK:

- SECUREGATE wordmark top-left
- EIP-777G subtitle under/near wordmark
- dark near-black terminal canvas
- left Auth-Gate sidebar
- neon circular SCAN control with cyan/magenta glow
- GENESIS OWNER AUTHENTICATION label
- DASHBOARD LOCKED warning block
- K1 COMPROMISED WALLET ADDRESS label/input
- LINK DEVICE button with magenta outline
- PASSKEY input + ENTER below LINK DEVICE
- same-device/different-device copy
- AUTH-GATE explanatory copy
- human fallback @hope_ology copy
- passkey issuance copy
- SCRUB cleanup copy
- center STANDALONE OPERATION card
- gold caution/disclaimer card
- top-right pink SCRUB button
- top-right yellow circular power button
- bottom/right THANK YOU envelope visual
- BUILT BY EMP
- @hope_ology

The public UI must NOT show:

- Made by Surf
- SurfAI
- Surf badge
- generic Surf scaffold
- generic SaaS tabbed shell as landing view
- Recovery / Protection / Admin / Status as the dominant first screen
- plain teal generic Auth-Gate shell
- generic shadcn/card dashboard look

============================================================
1. SOURCE RULE
============================================================

Use the accepted SecureGate source artifact only:

  securegate-eip777g-final.zip
  SHA256: 198f0637d476848040b108e367551b8a071ed23d3e0cc1c9c0da98c3535f39a3

If using the consolidated handoff bundle:

  securegate-eip777g-handoff.zip
  SHA256: be5073e2054744349d70efa888e47bde3d76f850c80ff4b7bb761d7350ffce85

Do not use:
- workspace wrapper ZIPs as source
- uploads/
- outputs/
- restored-original folders
- generic Surf scaffold source
- old markdown packs as implementation source

If the current GitHub repo contains the wrong Surf/generic UI, fix the frontend source from the accepted SecureGate source and DAPINK design target.

============================================================
2. WHAT TO CHANGE
============================================================

This is a FRONTEND VISUAL RESTORE task.

Patch actual frontend source files only unless a build error requires a minimal related fix.

Likely files:

  frontend/src/App.tsx
  frontend/src/index.css
  frontend/src/components/*
  frontend/src/lib/uiLabels.ts

Do NOT change unless absolutely required:

  contracts/SecureGate.sol
  out/SecureGate.sol/SecureGate.json
  backend/routes/deploy.js
  backend/routes/rpc.js
  backend route safety
  K1/K2/K3 model
  ABI
  Foundry artifacts

The accepted security/business logic must stay intact.

============================================================
3. REMOVE WRONG CURRENT SHELL
============================================================

Remove or demote the current wrong public shell:

- Recovery / Protection / Admin / Status tabs must not dominate the landing screen.
- “Made by Surf” badge must be removed.
- SurfAI / Surf branding must be removed.
- Generic topbar/network-selector-first layout must be removed from first view.
- Generic tabbed SaaS dashboard layout must be removed from first view.

If Recovery/Protection/Admin/Status functions still exist, they must be hidden behind the correct SecureGate visual flow and must not replace the DAPINK landing layout.

============================================================
4. EXACT TOPBAR REQUIREMENTS
============================================================

Topbar must match DAPINK:

Left:
  SECUREGATE
  EIP-777G

Right:
  SCRUB button, solid neon pink
  circular yellow power icon

Do not show:
  Made by Surf
  SurfAI
  Surf badge
  generic network selector as primary topbar object

============================================================
5. EXACT LEFT SIDEBAR REQUIREMENTS
============================================================

Left sidebar must match DAPINK order:

1. Neon circular SCAN button with cyan/magenta glow rings
2. GENESIS OWNER AUTHENTICATION
3. DASHBOARD LOCKED card
4. AUTHENTICATION OF K1 GENESIS OWNER REQUIRED
5. K1 COMPROMISED WALLET ADDRESS
6. K1 input
7. LINK DEVICE button
8. PASSKEY input + ENTER button below LINK DEVICE
9. Same-device / different-device copy:
   - Same device: press SCAN.
   - Different device: connect by USB first, then press LINK DEVICE.
10. AUTH-GATE section
11. Human fallback @hope_ology copy
12. Passkey issuance copy
13. SCRUB/session cleanup copy
14. Admin black-circle inside caution area, if present in the current design

Sidebar must be scrollable with the same dark/neon visual feel.

============================================================
6. EXACT CENTER CANVAS REQUIREMENTS
============================================================

Main canvas must match DAPINK:

- Large mostly empty near-black terminal canvas
- Center card with cyan border and heading:

  STANDALONE OPERATION

Text:

  This dashboard executes the authentication flow client-side.
  You are not submitting K1 authentication data to any operator, server, or third party.
  Cryptographic checks run in your browser.
  Chain reads use the server-supplied RPC configuration.
  RPC is not part of the auth gate.

Below it, gold caution card:

  BY USING SECUREGATE YOU ACKNOWLEDGE YOU ALREADY MADE A POOR LIFE CHOICE.
  PLUS YOU ARE CONSENTING TO NOT BLAME ME FOR ANYTHING. NFA. I'M JUST A STICK FIGURE.

============================================================
7. EXACT FOOTER REQUIREMENTS
============================================================

Footer / lower-right must show:

  THANK YOU
  BUILT BY EMP
  @hope_ology

Style:
- cyan / magenta / gold neon
- visually consistent with DAPINK
- no Made by Surf
- no SurfAI
- no generic scaffold badge

============================================================
8. PRESERVE FUNCTIONAL SECURITY MODEL
============================================================

Keep all accepted SecureGate behavior:

- K1 entered before SCAN/LINK/PASSKEY
- K1 binds to session
- SCRUB clears session
- SCAN = same-device Auth-Gate path
- LINK DEVICE = same Auth-Gate sweep via linked device
- 3 failed device attempts darken SCAN/LINK only
- PASSKEY path remains open
- human fallback remains open
- K1-bound passkey generation/display
- admin black-circle passkey generation, if implemented
- recovery unlock after Auth-Gate/passkey
- K1 auto-fill
- K2 public address only
- K3 public address only
- K3 immutable forced destination
- chain names only, no RPC URLs
- funding/gas via backend
- deploy route signedTx-only
- thank-you envelope separate from K3
- 2FA/proactive separate from recovery

Do not introduce:
- K2 private-key field
- K3 private-key field
- backend private-key custody
- public RPC URL
- overrideDestination
- overrideDest
- k2OverrideDest
- revoke UI
- operator UI
- QR flow
- Flashbots wording
- sweeper/bot wording
- production-ready claim

============================================================
9. DESIGN-LOCK VERIFIER REQUIRED
============================================================

Add a design-fidelity verifier so this cannot happen again.

Create:

  scripts/verify-design-fidelity.cjs

It must fail if public frontend source contains:

  Made by Surf
  SurfAI
  Surf AI
  generic Surf scaffold
  surf badge

It must also fail if the required DAPINK public labels are missing from frontend source:

  SECUREGATE
  EIP-777G
  GENESIS OWNER AUTHENTICATION
  DASHBOARD LOCKED
  K1 COMPROMISED WALLET ADDRESS
  LINK DEVICE
  PASSKEY
  AUTH-GATE
  STANDALONE OPERATION
  BY USING SECUREGATE YOU ACKNOWLEDGE
  SCRUB
  BUILT BY EMP
  @hope_ology

It must fail if Recovery / Protection / Admin / Status are used as the dominant landing shell.

Allowed:
Those words may exist only if they are not the first visible landing layout and not replacing DAPINK.

Add this verifier to the final proof command list.

============================================================
10. REQUIRED PROOF
============================================================

Return all of this.

A. Git diff:

  git diff -- frontend/src/App.tsx frontend/src/index.css frontend/src/components frontend/src/lib scripts/verify-design-fidelity.cjs

B. Backend untouched proof:

  git diff -- backend contracts out test

C. Grep proof:

  grep -RIn "Made by Surf\\|SurfAI\\|Surf AI\\|generic Surf\\|surf scaffold" frontend/src || true

This must return no public UI hits.

D. Required label proof:

  grep -RIn "GENESIS OWNER AUTHENTICATION\\|DASHBOARD LOCKED\\|STANDALONE OPERATION\\|BUILT BY EMP\\|@hope_ology" frontend/src

E. Build proof:

  cd frontend
  npm run type-check
  npm run build

F. Design verifier proof:

  node scripts/verify-design-fidelity.cjs

G. Live screenshot proof:

Attach a screenshot of the deployed Vercel page.

The screenshot must visually match DAPINK:
- neon SCAN circle
- left Auth-Gate sidebar
- STANDALONE OPERATION card
- gold caution card
- pink SCRUB
- yellow power icon
- THANK YOU / BUILT BY EMP / @hope_ology
- no Made by Surf

H. Final statement:

  The DAPINK screenshot was used as the visual source of truth.
  The previous Surf/generic tabbed shell was removed from the public landing view.
  Backend/contracts/K1-K2-K3 logic were not changed.

Final line must be exactly:

No production-ready claim.
```

---

## One-Line Instruction If You Need Short

```txt
Restore the frontend to match DAPINK exactly; remove Made by Surf/SurfAI/generic tab shell; keep SecureGate logic/backend/contracts unchanged; add a design-fidelity verifier that fails if DAPINK labels are missing or Surf branding appears; prove with frontend diff, build output, verifier output, and live screenshot. No production-ready claim.
```

## Acceptance Rule

Do **not** accept:

```txt
Build passed
Vercel live
Verifier passed
Dashboard functional
```

unless they also provide:

```txt
DAPINK-matching screenshot
frontend diff
no Surf branding grep
design-fidelity verifier
backend/contracts untouched proof
```

**Bottom line.** The specs were clear. The new master prompt makes the screenshot legally binding: if it does not look like DAPINK, it fails.

No production-ready claim.